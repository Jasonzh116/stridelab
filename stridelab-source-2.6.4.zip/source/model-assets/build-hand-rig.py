"""Append a small authored digit rig to the existing CC BY-SA 4.0 Z-Anatomy asset.
No vertex positions, normals, faces, colors, existing nodes or non-hand weights change.
Reads source checkout; writes only --out. Requires numpy and vtk (original generator dependencies).
"""
from pathlib import Path
import argparse,json,gzip,base64,hashlib,copy,numpy as np,vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray,vtk_to_numpy
ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,default=Path(__file__).resolve().parent.parent);ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parent);args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
source=args.source;source_path=source/'model-assets/coherent-neutral-base.js';base=json.loads(source_path.read_text().split('=',1)[1].rstrip(';\n'));a=copy.deepcopy(base)
assert len(a['nodes'])==21, 'Expected original21-node neutralbase'
raw=json.loads((source/'model-assets/coherent-optimized.json').read_text());rig={b['name']:b for b in json.loads((source/'model-assets/rig-data.json').read_text())[0]['bones']};hand=[];ranges={};report={'sourceSHA256':hashlib.sha256(source_path.read_bytes()).hexdigest(),'sourceRigSHA256':hashlib.sha256((source/'model-assets/rig-data.json').read_bytes()).hexdigest(),'vtkVersion':vtk.vtkVersion.GetVTKVersion(),'nodeCountBefore':len(a['nodes']),'packed':{}}
def conv(v):return [float(v[0]),float(v[2]),-float(v[1])]
def axis(b,c):
 v=np.array(conv([b['matrix'][i][c] for i in range(3)]));return(v/np.linalg.norm(v)).tolist()
lookup={};metadata={}
for side,short,wrist in [('L','l',15),('R','r',18)]:
 word='Left' if side=='L' else 'Right';flexSign=-1 if side=='L' else 1
 for digit in range(1,6):
  chain=[]
  if digit==1:chain=[('CMC',word+'Thumb',10,5),('MCP',f'Proximal phalanx of hand-1st finger.{short}',25,30),('IP',f'Distal phalanx of hand-1st finger.{short}',30,0)]
  else:
   ordinal={2:'2nd',3:'3rd',4:'4th',5:'5th'}[digit];p=word+'FingerBase' if digit==3 else f'Proximal phalanx of hand-{ordinal} finger.{short}'
   chain=[('MCP',p,[80,80,80,65][digit-2],[-3,0,0,0][digit-2]),('PIP',f'Middle phalanx of hand-{ordinal} finger.{short}',[85,85,85,90][digit-2],0),('DIP',f'Distal phalanx of hand-{ordinal} finger.{short}',[60,60,60,50][digit-2],0)]
  parent=wrist
  for joint,n,flex,splay in chain:
   b=rig[n];name=f'digit{digit}{joint}{side}';idx=len(a['nodes']);node={'name':name,'p':conv(b['head']),'parent':parent};a['nodes'].append(node)
   entry={'name':name,'index':idx,'side':side,'digit':digit,'joint':joint,'sourceName':n,'flexAxis':axis(b,2),'splayAxis':axis(b,0),'flexDegrees':flex*flexSign,'splayDegrees':splay,'tail':conv(b['tail'])};hand.append(entry);lookup[(side,digit,joint)]=idx;metadata[idx]=entry;parent=idx

def smooth(t):t=max(0.,min(1.,float(t)));return t*t*(3-2*t)
def digitskin(p,side):
 # Only four long finger tendon branches exist in the delivered muscle objects.
 # Select a nearest source polyline; all inter-finger/palm seams remain wrist bound
 # until the smoothly weighted 10 mm MCP transition.
 best=None
 for digit in range(2,6):
  ids=[lookup[(side,digit,j)] for j in ['MCP','PIP','DIP']];pts=[np.array(a['nodes'][idx]['p'])for idx in ids]+[np.array(metadata[ids[-1]]['tail'])];lengths=[np.linalg.norm(pts[k+1]-pts[k])for k in range(3)];cumulative=np.r_[0,np.cumsum(lengths)]
  for k in range(3):
   v=pts[k+1]-pts[k];t=np.dot(p-pts[k],v)/np.dot(v,v);tc=np.clip(t,0,1);distance=np.linalg.norm(p-(pts[k]+tc*v));s=cumulative[k]+(t if k==0 and t<0 else tc)*lengths[k]
   if best is None or distance<best[0]:best=(distance,s,ids,cumulative,pts)
 _,s,ids,cs,pts=best;wrist=15 if side=='L' else 18
 # Use continuous joint-bisector planes for blend weights. Nearest-segment
 # arclength jumps on the volar side of a bent source joint and stretched a
 # 2.275 mm ring-finger tendon edge to 8.648 mm in the fully closed pose.
 # Branch assignment is unchanged; only the distal tendon weights change.
 tangents=[(pts[k+1]-pts[k])/np.linalg.norm(pts[k+1]-pts[k]) for k in range(3)]
 axes=[tangents[0]]+[(tangents[k-1]+tangents[k])/np.linalg.norm(tangents[k-1]+tangents[k]) for k in [1,2]]
 boundaries=[(0,.010,wrist,ids[0]),(1,.0045,ids[0],ids[1]),(2,.0035,ids[1],ids[2])]
 for joint,width,left,right in boundaries:
  signed=np.dot(p-pts[joint],axes[joint])
  if signed<=width:
   t=smooth((signed+width)/(2*width));return {left:1-t,right:t}
 return {ids[-1]:1.}

def lodpart(part,low):
 p=np.array(part['positions'],dtype=np.float64);f=np.array(part['indices'],dtype=np.int64)
 if low and len(f)>12:
  poly=vtk.vtkPolyData();pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(p));poly.SetPoints(pts);cs=vtk.vtkCellArray();cs.SetCells(len(f),numpy_to_vtkIdTypeArray(np.c_[np.full(len(f),3),f].astype(np.int64).ravel(),deep=True));poly.SetPolys(cs);dec=vtk.vtkQuadricDecimation();dec.SetInputData(poly);dec.SetTargetReduction(1-max(6,int(len(f)*.025))/len(f));dec.Update();po=dec.GetOutput()
  if po.GetNumberOfPoints()>0:p=vtk_to_numpy(po.GetPoints().GetData());f=vtk_to_numpy(po.GetPolys().GetData()).reshape(-1,4)[:,1:]
 return p,f
numbers={'first':1,'second':2,'third':3,'fourth':4,'fifth':5}
for level in ['high','low']:
 buffers={};ranges[level]={'bone':[],'muscle':[]};offsets={'bone':0,'muscle':0};stats={}
 for kind in ['bone','muscle']:
  d=a[level][kind];n=d['count'];buf=bytearray(gzip.decompress(base64.b64decode(d['data'])));indices=np.frombuffer(buf,dtype='u1',count=n*4,offset=n*6).reshape(n,4);weights=np.frombuffer(buf,dtype='u1',count=n*4,offset=n*10).reshape(n,4);posq=np.frombuffer(buf,dtype='<u2',count=n*3).reshape(n,3);p=np.array(d['min'])+posq/65535*np.array(d['extent']);buffers[kind]=(buf,indices,weights,posq,p);stats[kind]={'changedVertices':0,'changedStructures':[]}
 for o in raw:
  kind=o['kind'];buf,indices,weights,posq,packedp=buffers[kind];name=o['name'];lower=name.lower();start=offsets[kind]
  for part in o['parts']:
   p,f=lodpart(part,level=='low');off=offsets[kind];qs=np.rint((p-np.array(a[level][kind]['min']))/np.array(a[level][kind]['extent'])*65535).astype('<u2');assert len(qs)==len(posq[off:off+len(p)]);assert np.max(abs(qs.astype(int)-posq[off:off+len(p)].astype(int)))<=1,(level,name,off,'source partition mismatch');offsets[kind]+=len(p)
  end=offsets[kind];ranges[level][kind].append({'name':name,'start':start,'end':end});side='L' if name.endswith('.l') else 'R';wr=15 if side=='L' else 18;changed=0
  if kind=='bone' and (('phalanx' in lower and 'hand' in lower)or lower.startswith('first metacarpal')):
   digit=next(v for k,v in numbers.items() if k in lower)
   joint='CMC' if 'metacarpal' in lower else 'MCP' if lower.startswith('proximal') else ('IP'if digit==1 else'DIP')if lower.startswith('distal')else'PIP'
   idx=lookup[(side,digit,joint)];assert np.all(indices[start:end,0]==wr)and np.all(weights[start:end,0]==255),(name,'unexpected original binding');indices[start:end]=[idx,0,0,0];weights[start:end]=[255,0,0,0];changed=end-start
  elif kind=='muscle' and (lower.startswith('humero-ulnar head of flexor digitorum superficialis')or lower.startswith('extensor digitorum.')):
   for i in range(start,end):
    if packedp[i,1]>.805:continue
    d=digitskin(packedp[i],side)
    if all(k==wr or v<1e-6 for k,v in d.items()):continue
    assert indices[i,0]==wr and weights[i,0]==255,(name,i,'distal tendon is not wrist-only')
    pairs=sorted(((k,v)for k,v in d.items()if v>1e-6),key=lambda kv:-kv[1]);is_=[k for k,v in pairs];ws=[round(v*255)for k,v in pairs];ws[0]+=255-sum(ws);is_+=[0]*(4-len(is_));ws+=[0]*(4-len(ws));indices[i]=is_;weights[i]=ws;changed+=1
  if changed:stats[kind]['changedVertices']+=changed;stats[kind]['changedStructures'].append({'name':name,'vertices':changed})
 for kind in ['bone','muscle']:
  d=a[level][kind];buf,indices,weights,posq,p=buffers[kind];n=d['count'];assert offsets[kind]==n;assert np.all(weights.sum(1)==255);assert indices.max()<len(a['nodes']);old=gzip.decompress(base64.b64decode(base[level][kind]['data']));assert buf[:n*6]==old[:n*6]and buf[n*14:]==old[n*14:];d['data']=base64.b64encode(gzip.compress(buf,compresslevel=9,mtime=0)).decode();stats[kind]['geometryColorIndexBytesIdentical']=True
 report['packed'][level]=stats
assert a['nodes'][:21]==base['nodes'];report['nodeCountAfter']=len(a['nodes']);report['standingPose']='All new joints identity by default; atlas bind geometry unchanged';a['handRig']={'source':'Digit pivots and axes from Z-Anatomy rig-data.json, transformed (x,z,-y); authored closed running fist with external thumb; kinematic pose only, not measured running hand motion','license':'CC BY-SA 4.0','sourceSHA256':report['sourceRigSHA256'],'digits':hand}
(args.out/'coherent-hand-data.js').write_text('export const anatomyPackage='+json.dumps(a,separators=(',',':'))+';\n')
(args.out/'hand-rig.json').write_text(json.dumps(a['handRig'],indent=2));(args.out/'hand-ranges.json').write_text(json.dumps(ranges,separators=(',',':')));(args.out/'hand-asset-report.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items()if k!='packed'},indent=2));print({lev:{k:v['changedVertices']for k,v in stats.items()}for lev,stats in report['packed'].items()})
