"""Patch only existing interspinous ligament skin bytes in an anatomy package.
No geometry, node, color, face, muscle, solver or render change. Requires numpy/vtk.
High source attachment rows inherit the exact existing frame of the nearest vertebral
bone surface. Low weights are transferred by closest triangle/barycentric projection
from those same high attachment weights, preserving the decimated source geometry.
Run: python patch_interspinous.py --repo REPO --out OUTPUT_DIRECTORY
"""
from pathlib import Path
import argparse,base64,gzip,hashlib,json
import numpy as np
import vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray,vtk_to_numpy
vtk.vtkObject.GlobalWarningDisplayOff()

def poly(p,f):
 o=vtk.vtkPolyData();pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(np.asarray(p,dtype=np.float64),deep=True));o.SetPoints(pts);cs=vtk.vtkCellArray();cs.SetCells(len(f),numpy_to_vtkIdTypeArray(np.c_[np.full(len(f),3),f].astype(np.int64).ravel(),deep=True));o.SetPolys(cs);return o

def decimate(p,f):
 d=vtk.vtkQuadricDecimation();d.SetInputData(poly(p,f));d.SetTargetReduction(1-max(6,int(len(f)*.025))/len(f));d.Update();po=d.GetOutput()
 if po.GetNumberOfPoints():return vtk_to_numpy(po.GetPoints().GetData()),vtk_to_numpy(po.GetPolys().GetData()).reshape(-1,4)[:,1:]
 return p,f

def unpack(d):
 n=d['count'];b=bytearray(gzip.decompress(base64.b64decode(d['data'])));p=np.frombuffer(b,dtype='<u2',count=n*3).reshape(-1,3)/65535*d['extent']+d['min'];si=np.frombuffer(b,dtype='u1',count=n*4,offset=n*6).reshape(-1,4);sw=np.frombuffer(b,dtype='u1',count=n*4,offset=n*10).reshape(-1,4);f=np.frombuffer(b,dtype='<u4',offset=n*17).reshape(-1,3);return b,p,si,sw,f

def nearest(p,f,query):
 lo=vtk.vtkStaticCellLocator();lo.SetDataSet(poly(p,f));lo.BuildLocator();ids=[];cps=[];dist=[]
 for q in query:
  cp=[0.,0.,0.];ci=vtk.reference(0);su=vtk.reference(0);dd=vtk.reference(0.);lo.FindClosestPoint(q,cp,ci,su,dd);ids.append(int(ci));cps.append(cp);dist.append(float(dd)**.5)
 return np.array(ids),np.array(cps),np.array(dist)

def make(repo,out,input_path=None):
 out.mkdir(parents=True,exist_ok=True);raw=json.loads((repo/'model-assets/coherent-optimized.json').read_text());source=input_path or repo/'src/anatomy/coherent-data.js';src=source.read_text();pkg=json.loads(src.split('=',1)[1].strip().rstrip(';'));orig=json.loads(src.split('=',1)[1].strip().rstrip(';'));nodes=pkg['nodes'];target=[(i,o)for i,o in enumerate(raw)if o['name']=='Interspinous ligaments'];assert len(target)==1;oi,target=target[0];assert target['kind']=='bone'and len(target['parts'])==1 and target['parts'][0]['material']=='Ligament'
 assert [n['name']for n in nodes[:5]]==['root','pelvis','lumbar','thorax','head'];assert len(nodes)==51
 data={lod:unpack(pkg[lod]['bone'])for lod in ['high','low']};ranges={};sp=[];sf=[];host=[];hostnames=[];so=0
 for lod in ['high','low']:
  b,p,si,sw,f=data[lod];off=foff=0
  for i,o in enumerate(raw):
   if o['kind']!='bone':continue
   for part in o['parts']:
    pp=np.asarray(part['positions']);ff=np.asarray(part['indices'])
    if lod=='low'and len(ff)>12:pp,ff=decimate(pp,ff)
    n=len(pp);nf=len(ff);tol=max(pkg[lod]['bone']['extent'])/65535*1.1
    assert np.max(np.abs(pp-p[off:off+n]))<=tol,(lod,o['name'],'source partition mismatch')
    if i==oi:ranges[lod]=(off,off+n,foff,foff+nf)
    if lod=='high'and (o['name'].startswith('Vertebra ')or o['name']in ['Atlas (C1)','Axis (C2)','Sacrum'] ) and part['material'].startswith('Bone'):
     assert np.all(si[off:off+n,0]==si[off,0])and np.all(sw[off:off+n,0]==255),'host is not rigid'
     sp.append(p[off:off+n]);sf.append(f[foff:foff+nf]-off+so);so+=n;host.extend([int(si[off,0])]*nf);hostnames.extend([o['name']]*nf)
    off+=n;foff+=nf
  assert off==len(p)and foff==len(f)
 sp=np.vstack(sp);sf=np.vstack(sf);a,z,fa,fz=ranges['high'];hp=data['high'][1][a:z];hf=data['high'][4][fa:fz]-a;ci,cp,dist=nearest(sp,sf,hp);hi=np.array(host)[ci];names=np.array(hostnames)[ci]
 # Independent expected source station check protects against accidental broad remapping.
 expected=np.array([4]*8+[3]*26+[2]*10+[1]*6);assert len(hp)==50 and np.array_equal(hi,expected),(hi,names)
 highw=np.zeros((len(hp),len(nodes)));highw[np.arange(len(hp)),hi]=1
 report={'method':'Transfer actual existing rigid vertebra frame at each high ligament attachment; barycentric high-to-low weight transfer; no positional edits','sourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'rawSHA256':hashlib.sha256((repo/'model-assets/coherent-optimized.json').read_bytes()).hexdigest(),'vtkVersion':vtk.vtkVersion.GetVTKVersion(),'nodes':len(nodes),'highAttachments':[{'vertex':i,'host':str(names[i]),'node':int(hi[i]),'surfaceDistanceMm':float(dist[i]*1000)}for i in range(len(hp))],'lods':{}}
 for lod in ['high','low']:
  b,p,si,sw,f=data[lod];before=bytes(b);a,z,fa,fz=ranges[lod];assert np.all(si[a:z,0]==3)and np.all(sw[a:z,0]==255),'source already changed or unexpected target binding'
  if lod=='high':weights=highw
  else:
   ci,cp,d=nearest(hp,hf,p[a:z]);weights=[]
   for tid,q in zip(ci,cp):
    tri=hp[hf[tid]];A=np.vstack([(tri[1]-tri[0]),(tri[2]-tri[0])]).T;uv=np.linalg.lstsq(A,q-tri[0],rcond=None)[0];bc=np.array([1-uv.sum(),*uv]);bc=np.maximum(0,bc);bc/=bc.sum();weights.append(bc@highw[hf[tid]])
   weights=np.array(weights)
  for j,w in enumerate(weights):
   idx=np.flatnonzero(w>1e-8);idx=idx[np.argsort(-w[idx],kind='stable')];assert len(idx)<=4;ww=np.round(w[idx]/sum(w[idx])*255).astype(np.int64);ww[0]+=255-ww.sum();si[a+j]=0;sw[a+j]=0;si[a+j,:len(idx)]=idx;sw[a+j,:len(idx)]=ww
  delta=np.flatnonzero(np.frombuffer(before,dtype='u1')!=np.frombuffer(b,dtype='u1'));n=len(p);allowed=np.zeros(len(b),dtype=bool);allowed[n*6+a*4:n*6+z*4]=True;allowed[n*10+a*4:n*10+z*4]=True;assert np.all(allowed[delta]);assert np.all(sw.sum(1)==255)
  pkg[lod]['bone']['data']=base64.b64encode(gzip.compress(bytes(b),compresslevel=9,mtime=0)).decode();report['lods'][lod]={'vertices':z-a,'faces':fz-fa,'startVertex':a,'endVertex':z,'changedBytes':len(delta),'changedVertices':int(np.count_nonzero(np.any(np.c_[np.frombuffer(before,dtype='u1',count=n*4,offset=n*6).reshape(-1,4)[a:z],np.frombuffer(before,dtype='u1',count=n*4,offset=n*10).reshape(-1,4)[a:z]]!=np.c_[si[a:z],sw[a:z]],axis=1))),'weights':[{'indices':x.tolist(),'weights':y.tolist()}for x,y in zip(si[a:z],sw[a:z])]}
 # Compare every field after excluding the intentionally updated compressed bone strings.
 for lod in ['high','low']:
  check=dict(pkg[lod]['bone']);check['data']=orig[lod]['bone']['data'];assert check==orig[lod]['bone'];assert pkg[lod]['muscle']==orig[lod]['muscle']
 assert pkg['nodes']==orig['nodes'] and pkg.get('handRig')==orig.get('handRig')
 candidate=out/'coherent-data.ligament-candidate.js';candidate.write_text('export const anatomyPackage='+json.dumps(pkg,separators=(',',':'))+';\n');report['candidateSHA256']=hashlib.sha256(candidate.read_bytes()).hexdigest();(out/'interspinous-patch-report.json').write_text(json.dumps(report,indent=2));print(json.dumps({'candidate':str(candidate),'lods':{lod:{k:v for k,v in report['lods'][lod].items()if k!='weights'}for lod in ['high','low']}}));return report
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--input',type=Path,help='Unpatched anatomy package, e.g. output of build-hand-rig.py');a=ap.parse_args();make(a.repo,a.out,a.input)
