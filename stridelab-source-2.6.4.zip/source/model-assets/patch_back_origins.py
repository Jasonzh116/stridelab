"""Bounded posterior-medial back origin weight consistency experiment.
Input must be the interspinous-corrected package. Changes skin indices/weights only
in four named objects, at source medial Tendon surfaces and adjacent origin fibers.
The high ligament's continuous barycentric attachment field is the donor. High
muscle-to-low LOD transfers only the weight change, preserving unrelated low weights.
"""
from pathlib import Path
import argparse,base64,gzip,hashlib,json
import numpy as np
from patch_interspinous import unpack,nearest,decimate
NAMES={'Latissimus dorsi muscle.r','Latissimus dorsi muscle.l','Descending part of trapezius muscle.r','Descending part of trapezius muscle.l'}

def smooth(x,a,b):t=np.clip((x-a)/(b-a),0,1);return t*t*(3-2*t)
def dense(si,sw,n):
 w=np.zeros((len(si),n))
 for i in range(4):np.add.at(w,(np.arange(len(si)),si[:,i]),sw[:,i]/255)
 return w

def sample_field(p,f,w,q):
 ci,cp,d=nearest(p,f,q);result=[]
 for j,x in zip(ci,cp):
  t=p[f[j]];uv=np.linalg.lstsq(np.vstack([t[1]-t[0],t[2]-t[0]]).T,x-t[0],rcond=None)[0];bc=np.maximum(0,[1-uv.sum(),*uv]);bc/=sum(bc);result.append(bc@w[f[j]])
 return np.array(result),d

def write_weights(si,sw,i,w):
 w=np.maximum(w,0);w/=w.sum();ix=np.flatnonzero(w>1e-8);ix=ix[np.argsort(-w[ix],kind='stable')][:4];ww=np.round(w[ix]/w[ix].sum()*255).astype(int);ww[0]+=255-ww.sum();si[i]=0;sw[i]=0;si[i,:len(ix)]=ix;sw[i,:len(ix)]=ww

def make(repo,source,out):
 out.mkdir(parents=True,exist_ok=True);src=source.read_text();pkg=json.loads(src.split('=',1)[1].strip().rstrip(';'));raw=json.loads((repo/'model-assets/coherent-optimized.json').read_text());nnode=len(pkg['nodes']);assert nnode==51;report={'inputSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'method':'Barycentric transfer from corrected high interspinous attachment field to posterior medial source Tendon surfaces, with shared continuous field faded into adjacent origin fibers. Low LOD receives barycentrically interpolated high weight delta.','bounds':{'yFull':[1.125,1.28],'yFadeEnds':[1.09,1.315],'absoluteXFull':.06,'absoluteXZero':.105,'tendonDistanceZero':.10,'posteriorZFull':-.075,'posteriorZZero':-.055},'lods':{}}
 # Existing high ligament field: exactly 50 vertices and four anatomical host regions.
 _,bp,bsi,bsw,bf=unpack(pkg['high']['bone']);off=foff=0;lig=None
 for o in raw:
  if o['kind']!='bone':continue
  nv=sum(len(p['positions'])for p in o['parts']);nf=sum(len(p['indices'])for p in o['parts'])
  if o['name']=='Interspinous ligaments':lig=(bp[off:off+nv],bf[foff:foff+nf]-off,dense(bsi[off:off+nv],bsw[off:off+nv],nnode))
  off+=nv;foff+=nf
 assert lig is not None and len(lig[0])==50;assert np.array_equal(lig[2].argmax(1),[4]*8+[3]*26+[2]*10+[1]*6)
 datasets={lod:unpack(pkg[lod]['muscle'])for lod in ['high','low']};partitions={}
 for lod in ['high','low']:
  data,p,si,sw,f=datasets[lod];off=foff=0;parts=[]
  for o in raw:
   if o['kind']!='muscle':continue
   for part in o['parts']:
    pp=np.array(part['positions']);ff=np.array(part['indices'])
    if lod=='low'and len(ff)>12:pp,ff=decimate(pp,ff)
    n=len(pp);nf=len(ff);assert np.max(abs(pp-p[off:off+n]))<max(pkg[lod]['muscle']['extent'])/65535*1.1
    parts.append({'name':o['name'],'material':part['material'],'a':off,'z':off+n,'fa':foff,'fz':foff+nf});off+=n;foff+=nf
  assert off==len(p);partitions[lod]=parts
 b,hp,hsi,hsw,hf=datasets['high'];hw=dense(hsi,hsw,nnode);originalHigh=hw.copy();changed={};partByKey={(p['name'],p['material']):p for p in partitions['high']}
 for name in NAMES:
  tendon=partByKey[(name,'Tendon')];tf=hf[tendon['fa']:tendon['fz']];tp=hp[tf];keep=np.all((abs(tp[:,:,0])<.045)&(tp[:,:,1]>1.085)&(tp[:,:,1]<1.32)&(tp[:,:,2]<-.07),axis=1);tf=tf[keep];assert len(tf)>10,(name,'missing medial tendon surface')
  for part in partitions['high']:
   if part['name']!=name:continue
   a,z=part['a'],part['z'];p=hp[a:z];gate=smooth(p[:,1],1.09,1.125)*(1-smooth(p[:,1],1.28,1.315))*(1-smooth(abs(p[:,0]),.06,.105))*(1-smooth(p[:,2],-.075,-.055));active=np.where(gate>1e-8)[0]
   if not len(active):continue
   _,_,distance=nearest(hp,tf,p[active]);factor=gate[active]*(1-smooth(distance,0,.10));active2=active[factor>1e-8];factor=factor[factor>1e-8];donor,_=sample_field(*lig,p[active2]);updated=hw[a+active2]*(1-factor[:,None])+donor*factor[:,None];hw[a+active2]=updated;changed[(name,part['material'])]=len(active2)
 highDelta=hw-originalHigh
 for lod in ['high','low']:
  b,p,si,sw,f=datasets[lod];before=bytes(b);beforeDense=dense(si,sw,nnode);allowedVertices=np.zeros(len(p),bool);partReports=[]
  for part in partitions[lod]:
   if part['name']not in NAMES:continue
   a,z=part['a'],part['z'];allowedVertices[a:z]=True
   if lod=='high':neww=hw[a:z]
   else:
    h=partByKey[(part['name'],part['material'])];delta,_=sample_field(hp[h['a']:h['z']],hf[h['fa']:h['fz']]-h['a'],highDelta[h['a']:h['z']],p[a:z]);neww=beforeDense[a:z]+delta
   changedCount=0
   for j,w in enumerate(neww):
    if np.max(abs(w-beforeDense[a+j]))<1e-8:continue
    write_weights(si,sw,a+j,w);changedCount+=1
   originalSi=np.frombuffer(before,dtype='u1',count=len(p)*4,offset=len(p)*6).reshape(-1,4);originalSw=np.frombuffer(before,dtype='u1',count=len(p)*4,offset=len(p)*10).reshape(-1,4);actualChanged=int(np.count_nonzero(np.any(si[a:z]!=originalSi[a:z],axis=1)|np.any(sw[a:z]!=originalSw[a:z],axis=1)));partReports.append({'name':part['name'],'material':part['material'],'startVertex':a,'endVertex':z,'changedVertices':actualChanged})
  n=len(p);delta=np.flatnonzero(np.frombuffer(before,dtype='u1')!=np.frombuffer(b,dtype='u1'));allowed=np.zeros(len(b),bool)
  for v in np.flatnonzero(allowedVertices):allowed[n*6+v*4:n*6+v*4+4]=True;allowed[n*10+v*4:n*10+v*4+4]=True
  assert np.all(allowed[delta]);assert np.all(sw.sum(1)==255)
  newDense=dense(si,sw,nnode);changedV=np.max(abs(newDense-beforeDense),axis=1)>0;assert np.all(abs(p[changedV,0])<.11);assert np.all((p[changedV,1]>1.07)&(p[changedV,1]<1.33));assert np.all(newDense[changedV,13:]==beforeDense[changedV,13:]),'distal/arm influence changed'
  pkg[lod]['muscle']['data']=base64.b64encode(gzip.compress(bytes(b),9,mtime=0)).decode();report['lods'][lod]={'changedBytes':int(len(delta)),'changedVertices':int(sum(changedV)),'parts':partReports,'changedBounds':[p[changedV].min(0).tolist(),p[changedV].max(0).tolist()]}
 candidate=out/'coherent-data.back-bindings-final.js';candidate.write_text('export const anatomyPackage='+json.dumps(pkg,separators=(',',':'))+';\n');report['candidateSHA256']=hashlib.sha256(candidate.read_bytes()).hexdigest();(out/'back-origin-final-report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report['lods'],indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--input',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();make(a.repo,a.input,a.out)
