from pathlib import Path
import json,numpy as np,struct,gzip,base64,vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray,vtk_to_numpy
ROOT=Path(__file__).resolve().parent;OUT=ROOT.parent/'src/anatomy';raw=json.loads((ROOT/'coherent-optimized.json').read_text());rig=json.loads((ROOT/'rig-data.json').read_text())[0]['bones'];rb={b['name']:b for b in rig}
def conv(p):return[p[0],p[2],-p[1]]
def rp(n):return conv(rb[n]['head'])
nodes=[{'name':'root','p':[0,0,0],'parent':-1},{'name':'pelvis','p':rp('Hips'),'parent':0},{'name':'lumbar','p':[0,1.08,-.04],'parent':1},{'name':'thorax','p':rp('Spine1'),'parent':2},{'name':'head','p':[0,1.50,-.025],'parent':3}]
for side,sgn,prefix in [('L',1,'Left'),('R',-1,'Right')]:
 i=len(nodes);nodes.extend([{'name':'hip'+side,'p':[sgn*.08377983,.86024266,-.00509209],'parent':1},{'name':'knee'+side,'p':rp('Tibia.'+side.lower()),'parent':i},{'name':'ankle'+side,'p':rp(prefix+'Foot'),'parent':i+1},{'name':'toes'+side,'p':[sgn*.105,.025,.083],'parent':i+2}])
for side,sgn,prefix in [('L',1,'Left'),('R',-1,'Right')]:
 i=len(nodes);nodes.extend([{'name':'shoulder'+side,'p':[sgn*.16726472,1.38179914,-.02666791],'parent':3},{'name':'elbow'+side,'p':rp(prefix+'ForeArm'),'parent':i},{'name':'wrist'+side,'p':rp(prefix+'Hand'),'parent':i+1}])
for side,sgn in [('L',1),('R',-1)]:nodes.append({'name':'patella'+side,'p':[sgn*.081,.444,.036],'parent':5 if side=='L' else 9})
ids={n['name']:i for i,n in enumerate(nodes)}
cn={'pectoralis':'胸大肌','deltoid':'三角肌','rectus abdominis':'腹直肌','external abdominal oblique':'腹外斜肌','trapezius':'斜方肌','latissimus':'背阔肌','serratus':'前锯肌','sternocleidomastoid':'胸锁乳突肌','infraspinatus':'冈下肌','teres major':'大圆肌','biceps brachii':'肱二头肌','triceps brachii':'肱三头肌','brachioradialis':'肱桡肌','pronator':'旋前圆肌','extensor':'伸肌群','flexor':'屈肌群','gluteus maximus':'臀大肌','gluteus medius':'臀中肌','tensor fasciae':'阔筋膜张肌','rectus femoris':'股直肌','vastus medialis':'股内侧肌','vastus lateralis':'股外侧肌','vastus intermedius':'股中间肌','biceps femoris':'股二头肌','semitendinosus':'半腱肌','semimembranosus':'半膜肌','sartorius':'缝匠肌','gracilis':'股薄肌','adductor':'内收肌群','gastrocnemius':'腓肠肌','soleus':'比目鱼肌','tibialis anterior':'胫骨前肌','fibularis':'腓骨肌群'}
def smooth(x,a,b):
 t=max(0.,min(1.,(x-a)/(b-a)));return t*t*(3-2*t)
def blend(a,b,t):return {a:1-t,b:t}
def baseTorso(y):
 if y<1.14:return blend(1,2,smooth(y,.98,1.14))
 return blend(2,3,smooth(y,1.14,1.29))
def bone_id(n,p):
 side='L'if n.endswith('.l')or p[0]>0 else'R';y=p[1];x=abs(p[0])
 if 'patella' in n:return ids['patella'+side]
 if 'femur' in n:return ids['hip'+side]
 if 'tibia' in n or 'fibula' in n:return ids['knee'+side]
 if 'humerus' in n:return ids['shoulder'+side]
 if n.startswith(('ulna','radius')):return ids['elbow'+side]
 if y<.16:return ids[('toes'if'phalanx'in n else'ankle')+side]
 if x>.18 and .65<y<1.18:return ids['wrist'+side]
 if 'hip bone'in n or 'sacrum'in n or 'coccy'in n or y<1.03:return 1
 if y>1.48:return 4
 if 'clavicle'in n or 'scapula'in n or 'rib'in n or 'sternum'in n or y>1.2:return 3
 return 2

def weights(n,p,mat):
 x,y,z=p;side='L'if n.endswith('.l') else 'R';sh=ids['shoulder'+side];el=ids['elbow'+side];wr=ids['wrist'+side];hi=ids['hip'+side];kn=ids['knee'+side];an=ids['ankle'+side];pa=ids['patella'+side];ax=abs(x)
 if 'sternocleidomastoid'in n:return blend(3,4,smooth(y,1.41,1.50))
 if any(k in n for k in ['pectoralis','latissimus','teres major','infraspinatus','trapezius']):
  d=baseTorso(y);t=smooth(ax,.11,.17)*smooth(y,1.20,1.34)*.92
  for k in list(d):d[k]*=1-t
  d[sh]=d.get(sh,0)+t;return d
 if any(k in n for k in ['rectus abdominis','oblique','serratus']):return baseTorso(y)
 if 'deltoid'in n:return blend(sh,3,smooth(y,1.345,1.425))
 if 'brachii'in n:
  if y>1.34:return blend(sh,3,smooth(y,1.34,1.41)*.65)
  return blend(el,sh,smooth(y,1.065,1.14))
 if any(k in n for k in ['carpi','digitorum superficialis','pronator','brachioradialis']) or ('extensor digitorum'in n and 'longus'not in n and 'brevis'not in n):
  if y>1.1:return blend(el,sh,smooth(y,1.1,1.15))
  return blend(wr,el,smooth(y,.86,.94))
 if 'gluteus'in n or'tensor fasciae'in n:return blend(hi,1,smooth(y,.80,.95))
 if any(k in n for k in ['vastus','rectus femoris','sartorius','biceps femoris','semitendinosus','semimembranosus','gracilis','adductor']):
  if y>.81 and 'vastus'not in n:return blend(hi,1,smooth(y,.81,.89))
  if 'vastus'in n or'rectus femoris'in n:
   if y<.452:return blend(kn,pa,smooth(y,.416,.452))
   return blend(pa,hi,smooth(y,.452,.50))
  return blend(kn,hi,smooth(y,.42,.49))
 if any(k in n for k in ['gastrocnemius','soleus','tibialis','fibularis','extensor hallucis','extensor digitorum longus','extensor digitorum brevis']):
  if y>.40 and'gastrocnemius'in n:return blend(kn,hi,smooth(y,.40,.465)*.85)
  return blend(an,kn,smooth(y,.075,.155))
 return baseTorso(y) if ax<.16 else {el:1}

def build(lod=False):
 bucket={'bone':{'p':[],'si':[],'sw':[],'c':[],'ix':[],'ranges':[]},'muscle':{'p':[],'si':[],'sw':[],'c':[],'ix':[],'ranges':[]}}
 for oi,o in enumerate(raw):
  b=bucket[o['kind']];startFace=len(b['ix'])//3;startVertex=len(b['p']);n=o['name'].lower()
  for part in o['parts']:
   p=np.array(part['positions'],dtype=np.float64);f=np.array(part['indices'],dtype=np.int64)
   if lod and len(f)>12:
    poly=vtk.vtkPolyData();pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(p));poly.SetPoints(pts);cs=vtk.vtkCellArray();cs.SetCells(len(f),numpy_to_vtkIdTypeArray(np.c_[np.full(len(f),3),f].astype(np.int64).ravel(),deep=True));poly.SetPolys(cs);dec=vtk.vtkQuadricDecimation();dec.SetInputData(poly);dec.SetTargetReduction(1-max(6,int(len(f)*.025))/len(f));dec.Update();po=dec.GetOutput()
    if po.GetNumberOfPoints()>0:p=vtk_to_numpy(po.GetPoints().GetData());f=vtk_to_numpy(po.GetPolys().GetData()).reshape(-1,4)[:,1:]
   offset=len(b['p']);mat=part['material'];color=[137,49,42]if o['kind']=='muscle'else[210,204,184]
   if'Tendon'in mat:color=[211,198,172]
   if'Cartilage'in mat:color=[180,191,182]
   rigid=bone_id(n,p.mean(0))
   for pt in p:
    d={rigid:1}if o['kind']=='bone'else weights(n,pt,mat);pairs=sorted(((i,w)for i,w in d.items()if w>1e-7),key=lambda t:-t[1])[:4];total=sum(w for _,w in pairs);idx=[i for i,w in pairs];wgt=[round(w/total*255)for i,w in pairs];wgt[0]+=255-sum(wgt);idx+=[0]*(4-len(idx));wgt+=[0]*(4-len(wgt));b['p'].append(pt);b['si'].append(idx);b['sw'].append(wgt);b['c'].append(color)
   b['ix'].extend((f+offset).reshape(-1).tolist())
  if o['kind']=='muscle':
   label=next((v for k,v in cn.items()if k in n),o['name']);side='左'if n.endswith('.l')else'右';b['ranges'].append({'id':oi,'name':o['name'],'label':side+label,'startFace':startFace,'endFace':len(b['ix'])//3,'startVertex':startVertex,'endVertex':len(b['p'])})
 result={}
 for kind,b in bucket.items():
  p=np.array(b['p']);lo=p.min(0);extent=p.max(0)-lo;pos=np.round((p-lo)/extent*65535).astype('<u2');si=np.array(b['si'],dtype='u1');sw=np.array(b['sw'],dtype='u1');col=np.array(b['c'],dtype='u1');ix=np.array(b['ix'],dtype='<u4');binary=pos.tobytes()+si.tobytes()+sw.tobytes()+col.tobytes()+ix.tobytes();packed=gzip.compress(binary,compresslevel=9)
  result[kind]={'count':len(p),'indexCount':len(ix),'min':lo.tolist(),'extent':extent.tolist(),'data':base64.b64encode(packed).decode(),'ranges':b['ranges']}
  print('LOD'if lod else'HIGH',kind,len(p),len(ix)//3,'bytes',len(packed),flush=True)
 return result
result={'nodes':nodes,'high':build(False),'low':build(True),'provenance':{'source':'Z-Anatomy / BodyParts3D','license':'CC BY-SA 4.0','commit':'cc407044f247e5ed31de42aab578093b24064e3e','rigging':'Derived joint centres and illustrative skin weights; no muscle force solver'}}
OUT.mkdir(exist_ok=True,parents=True);(OUT/'coherent-data.js').write_text('export const anatomyPackage='+json.dumps(result,separators=(',',':'))+';\n');(ROOT/'rig-nodes.json').write_text(json.dumps(nodes,indent=2));print('DONE', (OUT/'coherent-data.js').stat().st_size)
