# Constrained stance: implementation and interpretation

This mode is a static constrained-stance experiment. Running now uses a separate phase-dependent contact IK solver, documented in RUNNING-CONSTRAINTS.md. This module is not OpenSim Static Optimization or a dynamic running simulation.

## Coordinates and objectives
17 optimized coordinates: root translation XYZ; pelvis pitch/roll; each hip flexion and ab/adduction; each knee flexion; each ankle pitch/roll/yaw. Lumbar/thorax rotations distribute requested trunk inclination relative to the solved pelvis. Thigh/shank and all ordinary rig-segment lengths are fixed; the illustrative patella attachment retains its small prescribed sliding offset.

A bounded finite-difference Levenberg–Marquardt solve minimizes weighted residuals: planted contact-proxy positions (0.4 mm scale), support-margin violations (1 mm scale), last requested joint target (0.35° scale), COM centering (80 mm scale), spine limits, and a secondary mild posture/spinal-flexion preference. This objective selects one of many possible postures; it is not a universal law of human compensation. Each new joint input replaces the previous joint target. Trunk input releases the joint target.

Hard acceptance checks after minimization: support contact maximum coordinate error ≤1 mm, foot orientation error ≤1°, joint-coordinate bounds, COM margin ≥−0.1 mm, swing proxy clearance≥20 mm, lumbar flexion range. A rejected result is never shown as successful: the full previous feasible pose, including its actual trunk angle, is retained. The UI distinguishes desired and actual values. Failure of this local solve does not mathematically prove global infeasibility.

## Explicit quasi-static assumptions
The atlas is a single generic body, not measured anthropometry. Assumed mass70 kg and gravity9.81 m/s². Fractions sum1: pelvis.14, torso.378, head.07; each upper arm.027, forearm.016, hand.006, thigh.10, shank.045, foot.012. COM is the weighted sum of declared geometric segment-center interpolations. Feet use fixed neutral rectangular contact proxies at7 mm above the display ground, not scanned pressure maps.

Gravity acts vertically downward. A barycentric decomposition of COM ground projection into a triangulation of the support convex hull constructs one nonnegative vertical-reaction solution. It satisfies sum(Fy)=mg and horizontal-axis external moment balance, within numerical tolerance. The double-support allocation is underdetermined; the chosen triangulation is a numerical convention, not measured or uniquely predicted ground-reaction forces. No inertias, dynamic acceleration, friction cone, joint actuation limits, muscle force, reflexes, collision solver, or torque prediction are implemented. COM inside support is necessary under these assumptions, not sufficient evidence of physiological feasibility or dynamic balance.

Residual values only quantify the mathematical constraints. Submillimetre residuals do not mean submillimetre anatomical accuracy. Skinning is a visualization approximation; contact-proxy checks are separate from actual weighted mesh checks.

## Validation
Run `node scripts/test-constraints.mjs`. The independent suite covers mass/COM reconstruction, fixed lengths, joint bounds, foot contact, symmetry, trunk and target coupling, last-feasible holds, support switching, reset, invalid inputs, seeded stress cases, nonnegative reaction equilibrium, and low/high-resolution real model skinning. QA-constraints-unit.json contains266 results and source hashes. QA-constraints-browser.json records actual authenticated Chrome compatibility-mode interactions. High-detail WebGL remains untested in this cloud browser because GPU contexts are disabled.

## Engine assessment
Official MuJoCo JavaScript/WASM bindings exist: https://github.com/google-deepmind/mujoco/blob/main/wasm/README.md . A full dynamics integration would additionally need meaningful inertias, collision/contact geometry, actuator parameters and a balance/gait controller. OpenSim source: https://github.com/opensim-org/opensim-core . This release deliberately implements and tests the bounded static problem rather than label an animation as a dynamics result. No additional engine or asset dependency was imported.
