// Usage: node verify-performance-equivalence.mjs BASELINE_ROOT CANDIDATE_ROOT [--frames=160] [--report=report.json]
// Both roots must provide src/ plus their normal dependencies/assets.
// Imports and all tests are read-only. The optional report is the only output file.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const root=new URL('../',import.meta.url).pathname;const [baselineRoot=path.join(root,'scripts/fixtures/accepted-2.6.1'),candidateRoot=root,...options]=process.argv.slice(2);
if(!baselineRoot||!candidateRoot)throw Error('Supply baseline and candidate project roots');
const frames=Number(options.find(x=>x.startsWith('--frames='))?.split('=')[1]||160);
const reportFile=options.find(x=>x.startsWith('--report='))?.slice('--report='.length);
const moduleAt=(root,file)=>import(pathToFileURL(path.resolve(root,'src',file)));
const [baseRun,fastRun,baseSag,fastSag,baseStand,fastStand,reference]=await Promise.all([
 moduleAt(baselineRoot,'running-constraints.js'),moduleAt(candidateRoot,'running-constraints.js'),
 moduleAt(baselineRoot,'running-sagittal.js'),moduleAt(candidateRoot,'running-sagittal.js'),
 moduleAt(baselineRoot,'constraints.js'),moduleAt(candidateRoot,'constraints.js'),moduleAt(baselineRoot,'motion-reference.js')]);
const report={passed:false,baselineRoot,candidateRoot,framesPerCase:frames,cases:0,boneStates:0,held:0,firstFrameHeld:0,checks:[]};
function boneEqual(a,b,label){assert.equal(b.bones.length,a.bones.length);for(let i=0;i<a.bones.length;i++)for(const key of['position','quaternion','rotation','matrix','matrixWorld'])assert.deepEqual(b.bones[i][key].toArray(),a.bones[i][key].toArray(),`${label}: ${a.bones[i].name}.${key}`);report.boneStates+=a.bones.length;}
function resultEqual(a,b,x,y,label){assert.deepEqual(y,x,`${label}: complete result`);if(a.contactState)assert.deepEqual(b.contactState(),a.contactState(),`${label}: contact state`);boneEqual(a,b,label);report.cases++;report.held+=+!!x.held;}
const editOffsets=p=>({left:p>=.1&&p<1.1?{hip:10,knee:4,ankle:2,abduction:12,rotation:18}:{hip:0,knee:4,ankle:2,abduction:0,rotation:0},right:p>=.6&&p<1.6?{hip:-6,knee:4,ankle:2,abduction:-7,rotation:14}:{hip:0,knee:4,ankle:2,abduction:0,rotation:0}});
for(const speed of[2.5,3.5,4.5]){
 const gait=(p,k)=>reference.referenceGait(p,k,speed),make=(a,b)=>[a.createRunningSolver(gait,{speed}),b.createRunningSolver(gait,{speed})];
 for(const mode of['default','mixed']){
  const[a,b]=make(baseRun,fastRun);a.reset({rebase:true});b.reset({rebase:true});
  for(let i=0;i<frames;i++){
   const phase=i/(60*reference.referenceSets[speed].cycleSeconds),input={phase,trunk:8,offsets:mode==='default'?{left:{},right:{}}:editOffsets(phase%3),spatial:mode==='default'?{}:{pelvisRoll:2,pelvisYaw:5,thoraxYaw:6}};
   const x=a.solve(input),y=b.solve(input);resultEqual(a,b,x,y,`${speed}/${mode}/${i}`);
   a.apply(x.q,x.actualTrunk,x.actualPhase,x.actualSpatial);b.apply(y.q,y.actualTrunk,y.actualPhase,y.actualSpatial);boneEqual(a,b,`${speed}/${mode}/${i}/public apply`);
  }
  for(const rebase of[false,true]){a.reset({rebase});b.reset({rebase});const input={phase:.2,trunk:25,offsets:editOffsets(.2),spatial:{pelvisRoll:2,pelvisYaw:5,thoraxYaw:6}};resultEqual(a,b,a.solve(input),b.solve(input),`${speed}/${mode}/reset ${rebase}`)}
  report.checks.push(`60 Hz ${speed} m/s ${mode}, reset, complete results/state and all51 bones`);
 }
 for(const trunk of[-10,8,35])for(const mode of['default','mixed','extreme']){
  const[a,b]=make(baseRun,fastRun);a.reset({rebase:true});b.reset({rebase:true});const st=reference.referenceSets[speed].stance;
  const phases=[0,st-1e-7,st,st+1e-7,.5-1e-7,.5,.5+st-1e-7,.5+st,.9999999,1,1.001,1.1];
  for(let i=0;i<phases.length;i++){
   const offsets=mode==='default'?{left:{},right:{}}:mode==='mixed'?{left:{hip:15,knee:12,ankle:-6,abduction:10,rotation:-14},right:{hip:-10,knee:5,ankle:5,abduction:-8,rotation:12}}:{left:{hip:70,knee:100,ankle:70,abduction:35,rotation:40},right:{hip:-70,knee:-100,ankle:-70,abduction:-35,rotation:-40}};
   const input={phase:phases[i],trunk,offsets,spatial:mode==='default'?{}:{pelvisRoll:8,pelvisYaw:15,thoraxYaw:20}},x=a.solve(input),y=b.solve(input);
   resultEqual(a,b,x,y,`${speed}/${trunk}/${mode}/boundary ${i}`);if(i===0&&x.held)report.firstFrameHeld++;
  }
 }
 for(const trunk of[8,25,35]){
  const[a,b]=make(baseSag,fastSag);
  for(const phase of[0,.12,.32,.5,.75,.999]){
   const input={phase,trunk,offsets:{left:{hip:10,knee:5},right:{hip:-5,ankle:3}}};
   resultEqual(a,b,a.solve(input),b.solve(input),`sagittal solve ${speed}/${trunk}/${phase}`);
   const x=a.referenceAt(phase),y=b.referenceAt(phase);assert.deepEqual(y,x);boneEqual(a,b,`sagittal public referenceAt ${phase}`);
   assert.deepEqual(b.evaluate(y.q,input,true),a.evaluate(x.q,input,true));boneEqual(a,b,`sagittal public evaluate ${phase}`);
   a.apply(x.q,trunk,phase);b.apply(y.q,trunk,phase);boneEqual(a,b,`sagittal public apply ${phase}`);
  }
  a.reset({rebase:true});b.reset({rebase:true});const input={phase:.2,trunk,offsets:{left:{hip:8},right:{hip:-4}}};resultEqual(a,b,a.solve(input),b.solve(input),`sagittal reset ${speed}/${trunk}`);
 }
}
for(const support of['double','left','right']){
 const a=baseStand.createConstraintSolver(),b=fastStand.createConstraintSolver();
 const q=Array(17).fill(0);q[3]=.1;q[5]=.15;q[7]=.2;q[11]=-.1;q[13]=.1;
 a.apply(q,8,{pelvisYaw:.1,leftRotation:.2,rightRotation:-.1},true,true);
 b.apply(q,8,{pelvisYaw:.1,leftRotation:.2,rightRotation:-.1},true,true);
 // Default/public apply must exit the internal fast mode and restore all bones.
 a.apply(q,8);b.apply(q,8);boneEqual(a,b,`standing apply after internal fast ${support}`);
 for(const trunk of[8,20,35]){const input={trunk,support};resultEqual(a,b,a.solve(input),b.solve(input),`standing ${support}/${trunk}`)}
 a.reset();b.reset();resultEqual(a,b,a.solve({support,trunk:8}),b.solve({support,trunk:8}),`standing reset ${support}`);
}
report.checks.push('Contact boundaries, extreme valid inputs, held rollback, first-frame held','Standalone sagittal solve/referenceAt/evaluate/apply/reset','Standing after internal fast FK, public apply and reset');
report.passed=true;if(reportFile)fs.writeFileSync(reportFile,JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
