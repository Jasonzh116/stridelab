// Dependency-free regression harness (uses the app's already-installed Three.js).
// Real PerspectiveCamera, OrbitControls and input listeners; production state,
// camera/control setup, setView and rAF loop are extracted, not reimplemented.
// Canvas/WebGL render calls are instrumented stubs. This is scheduling/projection
// coverage, not a browser, physical-device, pixel-rendering or GPU FPS test.
// Optional: node scripts/test-camera-zoom.mjs --source /path/to/old/app.js
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

const root = new URL('../', import.meta.url);
const sourceArg = process.argv.indexOf('--source');
const source = fs.readFileSync(sourceArg < 0 ? new URL('src/app.js', root) : process.argv[sourceArg + 1], 'utf8');
function extract(pattern, name) {
  const result = source.match(pattern)?.[0];
  assert(result, `Could not extract production ${name}; update the harness if structure changed`);
  return result;
}
const stateSource = extract(/^const state=.*;$/m, 'initial state');
const cameraSource = extract(/camera=new THREE\.PerspectiveCamera\([^;]+\);/, 'camera');
const targetSource = extract(/target=new THREE\.Vector3\([^;]+\);/, 'target');
const setupSource = extract(/orbit=new OrbitControls\(camera,canvas\);[\s\S]*?setView\('perspective'\);/, 'OrbitControls setup');
const viewSource = extract(/^function setView\(name\).*$/m, 'setView');
const loopSource = extract(/^function loop\(now\).*$/m, 'animation loop');
const changeHookPattern = /orbit\.addEventListener\(['"]change['"],\s*\(\)\s*=>\s*\{\s*dirty\s*=\s*true;?\s*\}\);?/;

class EventSurface {
  constructor() {
    this.listeners = new Map();
    this.style = {};
    this.clientWidth = 1000;
    this.clientHeight = 700;
    this.captures = new Set();
  }
  addEventListener(type, listener, options = {}) {
    const entries = this.listeners.get(type) || [];
    if (!entries.some(entry => entry.listener === listener)) entries.push({ listener, options });
    this.listeners.set(type, entries);
  }
  removeEventListener(type, listener) {
    this.listeners.set(type, (this.listeners.get(type) || []).filter(entry => entry.listener !== listener));
  }
  dispatch(type, values = {}) {
    const event = { type, target: this, defaultPrevented: false, ...values };
    let activeOptions = {};
    event.preventDefault = () => { if (!activeOptions.passive) event.defaultPrevented = true; };
    for (const entry of [...(this.listeners.get(type) || [])]) {
      activeOptions = entry.options;
      entry.listener(event);
    }
    return event;
  }
  getRootNode() { return this.root || this; }
  getBoundingClientRect() { return { left: 0, top: 0, width: this.clientWidth, height: this.clientHeight }; }
  setPointerCapture(id) { this.captures.add(id); }
  releasePointerCapture(id) { this.captures.delete(id); }
}

function setup({ renderMode = 'canvas', mode = 'run', playing = false, reducedMotion = false, stripHook = false } = {}) {
  const canvas = new EventSurface(), document = new EventSurface();
  canvas.root = document;
  document.hidden = false;
  const ctx = {
    THREE, OrbitControls, canvas, document, scene: new THREE.Scene(),
    dirty: true, lastTime: 0, lastDraw: 0, uiElapsed: 0,
    poses: 0, overlays: 0, framesRequested: 0, hints: [], draws: [],
    model: { runningResult: { cycleSeconds: 0.78 } },
    matchMedia(query) { assert.equal(query, '(prefers-reduced-motion: reduce)'); return { matches: reducedMotion }; },
    $$() { return []; }, updateCameraHint(input) { ctx.hints.push(input); },
    pose() { ctx.poses++; ctx.dirty = true; }, updateUI() {},
    drawConstraintOverlay() { ctx.overlays++; },
    requestAnimationFrame(fn) { assert.equal(typeof fn, 'function'); ctx.framesRequested++; },
  };
  const context = vm.createContext(ctx);
  vm.runInContext(`${stateSource}\nthis.state=state;\n${cameraSource}\n${targetSource}\n${viewSource}\n${stripHook ? setupSource.replace(changeHookPattern, '') : setupSource}\n${loopSource}`, context);
  ctx.state.ready = true;
  ctx.state.renderMode = renderMode;
  ctx.state.mode = mode;
  // 'initial' retains the real reduced-motion-derived initial playing value.
  if (playing !== 'initial') ctx.state.playing = playing;
  ctx.state.phase = 0.37;
  function sample() {
    ctx.camera.updateMatrixWorld();
    const top = new THREE.Vector3(0, 1.39, 0).project(ctx.camera);
    const bottom = new THREE.Vector3(0, 0.39, 0).project(ctx.camera);
    return {
      distance: ctx.camera.position.distanceTo(ctx.orbit.target),
      height: Math.hypot(top.x - bottom.x, top.y - bottom.y),
      position: ctx.camera.position.toArray(), target: ctx.orbit.target.toArray(),
    };
  }
  ctx.renderer = { render(...args) {
    if (renderMode === 'webgl') { assert.equal(args.length, 2); assert.equal(args[0], ctx.scene); assert.equal(args[1], ctx.camera); }
    else assert.equal(args.length, 0);
    ctx.draws.push(sample());
  } };
  let now = 0;
  function tick(count = 1) { for (let i = 0; i < count; i++) ctx.loop(now += 1000 / 60); }
  function wheel(deltaY, deltaMode = 0, ctrlKey = false) {
    return canvas.dispatch('wheel', { deltaY, deltaMode, ctrlKey, clientX: 500, clientY: 350 });
  }
  function pointer(type, id, x, y = 350, pointerType = 'touch') {
    return canvas.dispatch(type, { pointerId: id, pointerType, pageX: x, pageY: y, clientX: x, clientY: y, button: 0 });
  }
  function clear() { ctx.draws.length = 0; ctx.poses = 0; ctx.overlays = 0; ctx.framesRequested = 0; }
  // Consume the initial draw (and initial playing step, when applicable).
  tick(); clear();
  return { ctx, canvas, tick, wheel, pointer, sample, clear, dispose: () => ctx.orbit.dispose() };
}

let passed = 0, failed = 0;
const results = [], boundaryObservations = [];
function test(name, body) {
  try { body(); passed++; results.push({ name, status: 'passed' }); }
  catch (error) { failed++; results.push({ name, status: 'failed', error: error.message }); console.error(`FAIL ${name}\n${error.stack}`); }
}
function near(actual, expected, tolerance = 1e-10) {
  assert(Math.abs(actual - expected) <= tolerance, `Expected ${actual} ≈ ${expected}`);
}
function finite(s) { assert([...s.position, ...s.target, s.distance, s.height].every(Number.isFinite)); }
function idle(h, count = 120) {
  const before = h.sample(), draws = h.ctx.draws.length, phase = h.ctx.state.phase;
  h.tick(count);
  assert.equal(h.ctx.draws.length, draws, 'idle controls must not trigger extra rendering');
  near(h.sample().distance, before.distance);
  near(h.sample().height, before.height);
  assert.equal(h.ctx.state.phase, phase);
}
function assertZoom(h, deltaY, deltaMode = 0, ctrlKey = false) {
  const before = h.sample(), phase = h.ctx.state.phase, playing = h.ctx.state.playing;
  const count = h.ctx.draws.length;
  const event = h.wheel(deltaY, deltaMode, ctrlKey);
  assert(event.defaultPrevented, 'wheel must prevent page scroll through its non-passive listener');
  const after = h.sample(); finite(after);
  assert(deltaY < 0 ? after.distance < before.distance : after.distance > before.distance);
  assert(deltaY < 0 ? after.height > before.height : after.height < before.height);
  assert.equal(h.ctx.state.phase, phase, 'camera input must not change gait phase');
  assert.equal(h.ctx.state.playing, playing, 'camera input must preserve playback');
  assert.equal(h.ctx.draws.length, count, 'input should schedule, not render synchronously');
  h.tick();
  assert.equal(h.ctx.draws.length, count + 1, 'camera change must draw on the very next frame');
  near(h.ctx.draws.at(-1).distance, after.distance);
  near(h.ctx.draws.at(-1).height, after.height);
  assert.equal(h.ctx.overlays, h.ctx.draws.length);
}

for (const renderMode of ['canvas', 'webgl']) {
  test(`${renderMode}: no-hook negative control reproduces stale paused frame`, () => {
    const h = setup({ renderMode, stripHook: true });
    const before = h.sample(); h.wheel(-120);
    assert(h.sample().distance < before.distance);
    assert.equal(h.ctx.dirty, false);
    assert.equal(h.ctx.orbit.update(), false, 'wheel already consumed the OrbitControls change');
    assert.throws(() => { h.tick(); assert.equal(h.ctx.draws.length, 1, 'missing redraw'); }, /missing redraw/);
    assert.equal(h.ctx.draws.length, 0);
    h.dispose();
  });

  for (const [label, options] of [
    ['paused run', { mode: 'run' }],
    ['standing constraint', { mode: 'constraint' }],
    ['constraint guards even a stale playing flag', { mode: 'constraint', playing: true }],
    ['standing pose', { mode: 'pose' }],
    ['reduced-motion initial pause', { reducedMotion: true, playing: 'initial' }],
  ]) for (const deltaMode of [0, 1, 2]) for (const sign of [-1, 1]) {
    test(`${renderMode}: ${label}, wheel mode ${deltaMode}, direction ${sign}`, () => {
      const h = setup({ renderMode, ...options });
      const phase = h.ctx.state.phase;
      const amount = deltaMode === 0 ? 120 : deltaMode === 1 ? 3 : 0.5;
      assertZoom(h, sign * amount, deltaMode);
      assert.equal(h.ctx.poses, 0);
      assert.equal(h.ctx.state.phase, phase);
      idle(h); h.dispose();
    });
  }

  for (const sign of [-1, 1]) test(`${renderMode}: ctrl-wheel trackpad pinch ${sign}`, () => {
    const h = setup({ renderMode, reducedMotion: true, playing: 'initial' });
    assert.equal(h.ctx.state.playing, false);
    assertZoom(h, sign * 8, 0, true);
    idle(h); h.dispose();
  });

  test(`${renderMode}: normal initial playback keeps running while zooming`, () => {
    const h = setup({ renderMode, playing: 'initial' });
    assert.equal(h.ctx.state.playing, true);
    const phase = h.ctx.state.phase;
    assertZoom(h, -120); assertZoom(h, 120);
    assert.equal(h.ctx.poses, 2);
    near(h.ctx.state.phase, (phase + 2 / 60 / 0.78) % 1);
    assert.equal(h.ctx.state.playing, true);
    h.ctx.state.playing = false; h.clear(); idle(h); h.dispose();
  });

  test(`${renderMode}: listener semantics and no-input idle`, () => {
    const h = setup({ renderMode });
    assert(h.canvas.listeners.get('wheel').some(entry => entry.options.passive === false));
    assert.equal(h.canvas.style.touchAction, 'none');
    assert.equal(h.ctx.orbit.minDistance, 1.65); assert.equal(h.ctx.orbit.maxDistance, 7);
    assert.equal(h.ctx.orbit.enableDamping, true); near(h.ctx.orbit.dampingFactor, 0.08);
    idle(h); h.wheel(0); idle(h);
    assert.equal(h.ctx.framesRequested, 240);
    h.dispose();
  });

  test(`${renderMode}: many wheel events coalesce to one frame`, () => {
    const h = setup({ renderMode });
    for (let i = 0; i < 12; i++) h.wheel(-4);
    assert.equal(h.ctx.draws.length, 0); assert.equal(h.ctx.dirty, true);
    const expected = h.sample(); h.tick();
    assert.equal(h.ctx.draws.length, 1); near(h.ctx.draws[0].distance, expected.distance);
    idle(h); h.dispose();
  });

  test(`${renderMode}: bounds clamp without visible jitter and direction can reverse`, () => {
    const h = setup({ renderMode });
    for (const [delta, bound] of [[-10000, 1.65], [10000, 7]]) {
      h.wheel(delta); h.tick(); near(h.sample().distance, bound); finite(h.sample());
      const atBound = h.sample();
      for (let i = 0; i < 20; i++) { h.wheel(delta); h.tick(); }
      near(h.sample().distance, bound); near(h.sample().height, atBound.height);
      h.tick(120); near(h.sample().distance, bound); near(h.sample().height, atBound.height);
    }
    assertZoom(h, -120); h.dispose();
  });

  for (const [delta, bound] of [[-10000, 1.65], [10000, 7]]) {
    test(`${renderMode}: bound ${bound} preserves upstream idle behavior`, () => {
      const observations = [];
      for (const stripHook of [true, false]) {
        const h = setup({ renderMode, stripHook });
        h.wheel(delta); h.tick(); h.clear();
        const before = h.sample(); h.tick(120); const after = h.sample();
        near(after.distance, bound); near(after.height, before.height);
        before.position.forEach((value, i) => near(after.position[i], value));
        observations.push({ hookEnabled: !stripHook, idleDraws: h.ctx.draws.length });
        h.dispose();
      }
      // r180 can report zoomChanged on roundoff at an exact clamp boundary.
      // Document this baseline behavior rather than promise zero idle renders.
      assert.equal(observations[1].idleDraws, observations[0].idleDraws);
      boundaryObservations.push({ renderMode, bound, idleFrames: 120, observations });
    });
  }

  test(`${renderMode}: alternating wheel directions have no accumulated jitter`, () => {
    const h = setup({ renderMode }), initial = h.sample();
    for (let i = 0; i < 50; i++) { assertZoom(h, -20); assertZoom(h, 20); }
    near(h.sample().distance, initial.distance); near(h.sample().height, initial.height);
    idle(h, 300); h.dispose();
  });

  test(`${renderMode}: reset-view and view presets remain zoomable`, () => {
    const h = setup({ renderMode }), initial = h.sample();
    assertZoom(h, -240); h.ctx.setView('perspective'); h.tick();
    near(h.sample().distance, initial.distance); near(h.sample().height, initial.height);
    for (const view of ['side', 'front', 'perspective']) {
      h.ctx.setView(view); h.tick(); assertZoom(h, -120); assertZoom(h, 120);
    }
    idle(h); h.dispose();
  });

  for (const mode of ['run', 'constraint']) for (const expanding of [true, false]) {
    test(`${renderMode}: real two-touch ${expanding ? 'spread' : 'pinch'} in ${mode}`, () => {
      const h = setup({ renderMode, mode }), before = h.sample(), phase = h.ctx.state.phase;
      h.pointer('pointerdown', 1, 450); h.pointer('pointerdown', 2, 550);
      h.pointer('pointermove', 1, expanding ? 425 : 460);
      h.pointer('pointermove', 2, expanding ? 575 : 540);
      const after = h.sample(); finite(after);
      assert(expanding ? after.distance < before.distance : after.distance > before.distance);
      assert(expanding ? after.height > before.height : after.height < before.height);
      assert.equal(h.ctx.state.phase, phase); assert.equal(h.ctx.poses, 0);
      assert.equal(h.ctx.draws.length, 0); h.tick(); assert.equal(h.ctx.draws.length, 1);
      h.pointer('pointerup', 1, 450); h.pointer('pointerup', 2, 550);
      assert.equal(h.canvas.listeners.get('pointermove').length, 0);
      assert.equal(h.canvas.listeners.get('pointerup').length, 0);
      // Default two-touch dolly-pan also leaves damped pan motion to settle.
      h.tick(500); idle(h, 120); assert.equal(h.ctx.state.phase, phase);
      assertZoom(h, -20); h.dispose();
    });
  }

  test(`${renderMode}: rotation damping still redraws then settles`, () => {
    const h = setup({ renderMode }), before = h.sample();
    h.pointer('pointerdown', 3, 500, 350, 'mouse');
    h.pointer('pointermove', 3, 580, 370, 'mouse');
    h.pointer('pointerup', 3, 580, 370, 'mouse');
    h.tick(10); assert(h.ctx.draws.length > 1);
    assert.notDeepEqual(h.sample().position, before.position);
    h.tick(500); idle(h); h.dispose();
  });

  test(`${renderMode}: hidden tab defers dirty camera frame until visible`, () => {
    const h = setup({ renderMode });
    h.ctx.document.hidden = true; h.wheel(-120); h.tick(3);
    assert.equal(h.ctx.draws.length, 0); assert.equal(h.ctx.dirty, true);
    h.ctx.document.hidden = false; h.tick(); assert.equal(h.ctx.draws.length, 1);
    idle(h); h.dispose();
  });
}
console.log(`${failed ? 'FAIL' : 'PASS'} ${passed}/${passed + failed} camera/input/render-scheduling cases (${THREE.REVISION} Three.js).`);
console.log('Real camera and OrbitControls; synthetic DOM/input/rAF; stub Canvas/WebGL render dispatch. Includes no-hook negative controls; excludes browser/device and pixel/GPU rendering.');
if (failed) process.exitCode = 1;

if (sourceArg < 0) fs.writeFileSync(new URL('QA-camera-zoom.json', root), JSON.stringify({
  status: failed ? 'failed' : 'passed', passed, failed, cases: passed + failed,
  threeRevision: THREE.REVISION,
  scope: 'Real Three.js PerspectiveCamera and OrbitControls with production state, camera/control setup, setView and loop extracted from src/app.js; synthetic DOM/input/rAF; instrumented Canvas/WebGL renderer dispatch.',
  limitations: [
    'No browser/device integration, actual GPU or Canvas pixel rendering, anatomical solver, overlay pixel correctness or device FPS measurement.',
    'Camera hint UI is stubbed and tested separately.',
    'At exact min/max zoom boundaries Three.js r180 may repeatedly report zoomChanged due to roundoff; camera stability and before/after parity are tested, not a zero-idle-render claim at the bounds.'
  ],
  boundaryObservations, results,
}, null, 2) + '\n');
