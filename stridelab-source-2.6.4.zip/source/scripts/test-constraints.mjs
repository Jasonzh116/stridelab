/** Independent numerical and real-model QA for the quasi-static stance experiment.
 * Run from project root: node scripts/test-constraints.mjs
 * No renderer, browser, downloaded dependency, or runtime edits are required.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import * as THREE from 'three';
import {createConstraintSolver, mechanicsAssumptions} from '../src/constraints.js';
import {createAnatomy} from '../src/model.js';
import {anatomyPackage} from '../src/anatomy/coherent-data.js';

const directory=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const RAD=Math.PI/180;
const nodes=anatomyPackage.nodes;
const tests=[], cases=[], integration=[];
const near=(a,b,t,message)=>assert.ok(Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=t,`${message}: ${a} vs ${b} (tolerance ${t})`);
const maxDelta=(a,b)=>Math.max(...a.map((x,i)=>Math.abs(x-b[i])));
const vec=()=>new THREE.Vector3();
function test(name,fn){const start=performance.now();try{const detail=fn();tests.push({name,status:'passed',milliseconds:Math.round(performance.now()-start),...(detail===undefined?{}:{detail})});}catch(error){tests.push({name,status:'failed',milliseconds:Math.round(performance.now()-start),message:error.message});}}
const supportSides=support=>support==='double'?['left','right']:[support];
function summary(input,result){return {input,status:result.status,feasible:result.feasible,held:result.held,targetMet:result.targetMet,actualTrunkDegrees:result.actualTrunk,trunkErrorDegrees:result.trunkError,footErrorMeters:result.footError,rotationErrorDegrees:result.rotationError,stabilityMarginMeters:result.margin,targetErrorDegrees:result.targetError,forceResidualNewtons:result.forceResidual,momentResidualNewtonMeters:result.momentResidual,swingClearanceMeters:result.clearance,spineDegrees:result.spine,angles:result.angles};}
function independentCOM(solver){
 const f=mechanicsAssumptions.massFractions;
 const segmentDefs=[['pelvis','lumbar',f.pelvis,.5],['lumbar','head',f.torso,.53],['head',null,f.head,0]];
 for(const suffix of ['L','R'])segmentDefs.push(['hip'+suffix,'knee'+suffix,f.thigh,.43],['knee'+suffix,'ankle'+suffix,f.shank,.43],['ankle'+suffix,'toes'+suffix,f.foot,.55],['shoulder'+suffix,'elbow'+suffix,f.upperArm,.44],['elbow'+suffix,'wrist'+suffix,f.forearm,.43],['wrist'+suffix,null,f.hand,0]);
 const sum=vec();let total=0;
 for(const [start,end,mass,fraction] of segmentDefs){const bone=solver.byName[start],a=bone.getWorldPosition(vec());if(end)a.lerp(solver.byName[end].getWorldPosition(vec()),fraction);else a.add(new THREE.Vector3(0,start==='head'?.09:-.06,0).applyQuaternion(bone.getWorldQuaternion(new THREE.Quaternion())));sum.addScaledVector(a,mass);total+=mass;}
 return {com:sum.divideScalar(total),total};
}
function inspect(solver,result,input){
 assert.equal(result.q.length,17,'17 generalized coordinates');
 result.q.forEach((q,i)=>{assert.ok(Number.isFinite(q),`q[${i}] must be finite`);assert.ok(q>=solver.bounds[i][0]-1e-12&&q<=solver.bounds[i][1]+1e-12,`q[${i}] outside bounds`);});
 assert.ok(['converged','target-limited','held','infeasible'].includes(result.status),'known status');
 const actualTrunk=result.actualTrunk??result.trunk??input.trunk;
 near(result.actualTrunk,actualTrunk,0,'explicit actual trunk');
 near(result.trunkError,actualTrunk-input.trunk,1e-12,'requested versus delivered trunk residual');
 if(!result.held)near(actualTrunk,input.trunk,0,'unheld trunk target');
 solver.apply(result.q,actualTrunk);
 let footError=0,rotationError=0,maxBoneLengthError=0;
 const allFeet={};
 for(const side of ['left','right']){
  const suffix=side==='left'?'L':'R',ankle=solver.byName['ankle'+suffix],bindAnkle=nodes.find(n=>n.name==='ankle'+suffix).p;
  const corners=[[-.038,.007,-.070],[.038,.007,-.070],[.038,.007,.155],[-.038,.007,.155]];
  allFeet[side]=corners.map(([x,y,z])=>new THREE.Vector3(x,y-bindAnkle[1],z).applyMatrix4(ankle.matrixWorld));
  if(supportSides(input.support).includes(side)){
   corners.forEach(([x,y,z],i)=>{const target=[x+bindAnkle[0],y,z+bindAnkle[2]],point=allFeet[side][i].toArray();footError=Math.max(footError,maxDelta(point,target));});
   const rotation=ankle.getWorldQuaternion(new THREE.Quaternion());rotationError=Math.max(rotationError,2*Math.acos(Math.min(1,Math.abs(rotation.w)))/RAD);
  }
 }
 for(let i=1;i<nodes.length;i++){
  // Patella attachment translation is an explicitly implemented accessory tracking
  // offset, not femur/tibia length or a scalable bone segment.
  if(nodes[i].name.startsWith('patella'))continue;
  const node=nodes[i],parent=nodes[node.parent];
  const bindLength=new THREE.Vector3(...node.p).distanceTo(new THREE.Vector3(...parent.p));
  const worldLength=solver.bones[i].getWorldPosition(vec()).distanceTo(solver.bones[node.parent].getWorldPosition(vec()));
  maxBoneLengthError=Math.max(maxBoneLengthError,Math.abs(bindLength-worldLength));
 }
 near(footError,result.footError,1e-12,'reported support-foot translation residual');
 near(rotationError,result.rotationError,3e-6,'reported support-foot orientation residual');
 assert.ok(maxBoneLengthError<2e-14,`load-bearing rigid segment length drift ${maxBoneLengthError}`);
 const normalized=independentCOM(solver);
 const diagnosticCOM=new THREE.Vector3(...result.com);
 const comError=diagnosticCOM.distanceTo(normalized.com);
 const polygon=result.supportPolygon;
 const margins=polygon.map((a,i)=>{const b=polygon[(i+1)%polygon.length];return ((b[0]-a[0])*(diagnosticCOM.z-a[1])-(b[1]-a[1])*(diagnosticCOM.x-a[0]))/Math.hypot(b[0]-a[0],b[1]-a[1]);});
 near(Math.min(...margins),result.margin,1e-12,'reported support polygon margin');
 if(input.driver){const index=(input.driver.side==='left'?5:11)+{hip:0,knee:2,ankle:3}[input.driver.joint];near(result.q[index]/RAD-input.driver.value,result.targetError,1e-10,'reported target residual');}
 let forceResidual=null,momentResidual=null,normalizedMomentResidual=null,minReaction=null;
 if(result.reactions){
  const load=mechanicsAssumptions.massKg*mechanicsAssumptions.gravity;
  let sum=0,momentX=0,momentZ=0;minReaction=Infinity;
  for(const reaction of result.reactions){assert.ok(Number.isFinite(reaction.n),'finite normal reaction');assert.ok(reaction.n>=-1e-7,`negative normal reaction ${reaction.n}`);minReaction=Math.min(minReaction,reaction.n);sum+=reaction.n;momentX+=reaction.p[1]*reaction.n;momentZ+=reaction.p[0]*reaction.n;}
  forceResidual=Math.abs(sum-load);
  momentResidual=Math.hypot(momentX-load*diagnosticCOM.z,momentZ-load*diagnosticCOM.x);
  normalizedMomentResidual=Math.hypot(momentX-load*normalized.com.z,momentZ-load*normalized.com.x);
  near(forceResidual,result.forceResidual,1e-9,'independently summed vertical forces');
  near(momentResidual,result.momentResidual,1e-9,'independently summed moments');
  assert.ok(forceResidual<1e-9,'vertical reaction sum equals model weight');
  assert.ok(momentResidual<1e-9,'gravity and contact moments balance at reported COM');
 }
 return {footError,rotationError,maxBoneLengthError,normalizedCOMErrorMeters:comError,declaredMassFractionSum:normalized.total,forceResidual,momentResidual,normalizedCOMMomentResidualNewtonMeters:normalizedMomentResidual,minReaction};
}
function assertRenderedFeasible(result){
 assert.ok(result.footError<=.001,`foot displacement ${result.footError} m`);
 assert.ok(result.rotationError<=1,`foot orientation ${result.rotationError}°`);
 assert.ok(result.margin>=-.0001,`COM outside support: ${result.margin} m`);
 assert.ok(result.clearance===null||result.clearance>=.02,`swing clearance ${result.clearance} m`);
 assert.ok(result.spine>=-15.2&&result.spine<=45.2,`spine ${result.spine}° out of range`);
 assert.ok(result.reactions!==null,'no unilateral reaction solution');
 assert.ok(result.forceResidual!==null&&result.momentResidual!==null,'missing gravity equilibrium residual');
}

let neutral,lean,left,right;
test('Declared model masses sum to unit body mass',()=>{
 const f=mechanicsAssumptions.massFractions,sum=f.pelvis+f.torso+f.head+2*(f.upperArm+f.forearm+f.hand+f.thigh+f.shank+f.foot);near(sum,1,1e-12,'declared total mass fraction');return {sum,massKg:mechanicsAssumptions.massKg};
});
const caseDefinitions=[
 ['Neutral double support',{trunk:0,support:'double'}],
 ['Trunk lean -10 degrees',{trunk:-10,support:'double'}],
 ['Trunk lean +35 degrees',{trunk:35,support:'double'}],
 ['Left single support',{trunk:0,support:'left'}],
 ['Right single support',{trunk:0,support:'right'}],
 ...['left','right'].map(side=>[`${side} knee +30 degrees`,{trunk:0,support:'double',driver:{side,joint:'knee',value:30}}]),
 ...['double','left','right'].flatMap(support=>[-10,0,35].flatMap(trunk=>['left','right'].flatMap(side=>[['knee',140],['hip',85],['ankle',-35],['ankle',30]].map(([joint,value])=>[`${support} trunk ${trunk} ${side} ${joint} ${value}`,{trunk,support,driver:{side,joint,value}}]))))
];
for(const [name,input] of caseDefinitions){
 const solver=createConstraintSolver();const result=solver.solve(input);const entry=summary(input,result);cases.push(entry);
 if(name==='Neutral double support')neutral=result;
 if(name==='Trunk lean +35 degrees')lean=result;
 if(name==='Left single support')left=result;
 if(name==='Right single support')right=result;
 test(`${name}: geometry, bounds and reported residuals`,()=>entry.independent=inspect(solver,result,input));
 test(`${name}: delivered pose preserves contact and equilibrium`,()=>assertRenderedFeasible(result));
 test(`${name}: normalized COM and gravity moments`,()=>{
  const independent=entry.independent??inspect(solver,result,input);
  assert.ok(independent.normalizedCOMErrorMeters<1e-10,`COM is not normalized: ${independent.normalizedCOMErrorMeters} m error`);
  assert.ok(independent.normalizedCOMMomentResidualNewtonMeters!==null&&independent.normalizedCOMMomentResidualNewtonMeters<1e-8,`gravity moments about normalized COM: ${independent.normalizedCOMMomentResidualNewtonMeters} Nm`);
 });
 if(name.includes('knee +30'))test(`${name}: requested target attained`,()=>{assert.equal(result.status,'converged');assert.ok(Math.abs(result.targetError)<=1);});
}
test('Trunk lean changes pelvis and coupled lower-body coordinates',()=>{
 assert.ok(maxDelta(neutral.q,lean.q)>.05,'unchanged lower-body generalized coordinates');
 assert.ok(Math.abs(neutral.q[3]-lean.q[3])>.02,'pelvis pitch did not respond');
 assert.ok(Math.abs(neutral.q[5]-lean.q[5])>.02,'hip did not respond');
 return {pelvisPitchChangeDegrees:(lean.q[3]-neutral.q[3])/RAD,hipChangeDegrees:(lean.q[5]-neutral.q[5])/RAD,pelvisTranslationChangeMeters:maxDelta(neutral.q.slice(0,3),lean.q.slice(0,3))};
});
test('Single-support solutions are bilateral mirrors',()=>{
 const pairs=[[0,0,-1],[1,1,1],[2,2,1],[3,3,1],[4,4,-1]];
 for(let offset=0;offset<6;offset++){const sign=[1,-1,1,1,-1,-1][offset];pairs.push([5+offset,11+offset,sign],[11+offset,5+offset,sign]);}
 const maxError=Math.max(...pairs.map(([a,b,sign])=>Math.abs(left.q[a]-sign*right.q[b])));
 assert.ok(maxError<2e-5,`mirrored generalized-coordinate mismatch ${maxError}`);
 near(left.footError,right.footError,2e-7,'mirrored contact residuals');near(left.margin,right.margin,2e-5,'mirrored stability margin');return {maxGeneralizedCoordinateError:maxError};
});
test('Infeasible knee target holds same-trunk contact without foot slip',()=>{
 const solver=createConstraintSolver(),input={trunk:0,support:'double',driver:{side:'left',joint:'knee',value:30}},before=solver.solve(input),impossible={...input,driver:{...input.driver,value:140}},after=solver.solve(impossible);
 assert.equal(after.held,true);assert.equal(after.status,'held');assert.equal(after.targetMet,false);near(maxDelta(before.q,after.q),0,0,'held coordinates');near(maxDelta(before.feet.left.flat(),after.feet.left.flat()),0,0,'held left foot');near(maxDelta(before.feet.right.flat(),after.feet.right.flat()),0,0,'held right foot');assertRenderedFeasible(after);return summary(impossible,after);
});
for(const support of ['double','left','right'])test(`Changing trunk after a saturating target preserves a feasible ${support} pose`,()=>{
 const solver=createConstraintSolver(),before=solver.solve({trunk:35,support,driver:{side:'left',joint:'hip',value:85}});
 const input={trunk:-10,support,driver:{side:'left',joint:'knee',value:140}},result=solver.solve(input);cases.push(summary(input,result));assertRenderedFeasible(result);inspect(solver,result,input);
 if(result.held){near(result.actualTrunk,before.actualTrunk,0,'held actual trunk');near(maxDelta(result.q,before.q),0,0,'held all coordinates');near(result.trunkError,result.actualTrunk-input.trunk,0,'held trunk target error');}
 return summary(input,result);
});
test('Infeasible targets after support switches hold a fresh valid baseline for the new support',()=>{
 const solver=createConstraintSolver(),rows=[];
 const requests=[{trunk:35,support:'left',driver:{side:'left',joint:'hip',value:85}},{trunk:-10,support:'left',driver:{side:'left',joint:'knee',value:140}},{trunk:-10,support:'right',driver:{side:'right',joint:'knee',value:140}},{trunk:35,support:'double',driver:{side:'right',joint:'knee',value:140}},{trunk:0,support:'left',driver:{side:'left',joint:'knee',value:140}}];
 let previousSupport=null;
 for(const input of requests){const result=solver.solve(input);assertRenderedFeasible(result);inspect(solver,result,input);if(input.support!==previousSupport)near(result.actualTrunk,input.trunk,0,'new support must use its own requested-trunk baseline');previousSupport=input.support;rows.push(summary(input,result));}
 return rows;
});
test('Seeded input-history stress preserves contact and reports held trunk honestly',()=>{
 const solver=createConstraintSolver();let seed=937162,maxFootError=0,minMargin=Infinity,held=0;
 const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 for(let i=0;i<72;i++){
  const support=['double','left','right'][Math.floor(random()*3)],side=random()<.5?'left':'right',joint=['hip','knee','ankle'][Math.floor(random()*3)];
  const limits={hip:[-35,85],knee:[0,140],ankle:[-35,30]}[joint],value=i%4===0?limits[1]+40:limits[0]+random()*(limits[1]-limits[0]);
  const input={trunk:-10+random()*45,support,driver:{side,joint,value}},result=solver.solve(input);
  assertRenderedFeasible(result);inspect(solver,result,input);maxFootError=Math.max(maxFootError,result.footError);minMargin=Math.min(minMargin,result.margin);held+=Number(result.held);
 }
 return {cases:72,held,maxFootErrorMeters:maxFootError,minStabilityMarginMeters:minMargin};
});
test('Deterministic fresh solution and reset after infeasible history',()=>{
 const input={trunk:20,support:'left',driver:{side:'left',joint:'knee',value:30}},a=createConstraintSolver(),b=createConstraintSolver(),initial=a.solve(input),fresh=b.solve(input);
 near(maxDelta(initial.q,fresh.q),0,0,'fresh deterministic coordinates');
 a.solve({trunk:-10,support:'right',driver:{side:'right',joint:'hip',value:85}});a.solve({trunk:35,support:'double',driver:{side:'left',joint:'knee',value:140}});a.reset();const reset=a.solve(input);near(maxDelta(initial.q,reset.q),0,0,'reset coordinates');near(initial.footError,reset.footError,0,'reset residual');return {maxCoordinateDifference:maxDelta(initial.q,reset.q)};
});
test('Malformed and nonfinite requested inputs reject without poisoning later solves',()=>{
 const invalid=[null,undefined,{}, {trunk:NaN,support:'double'},{trunk:Infinity,support:'left'},{trunk:'0',support:'double'},{trunk:-10.001,support:'double'},{trunk:35.001,support:'double'},{trunk:0,support:'both'},{trunk:0,support:'double',driver:{side:'middle',joint:'knee',value:30}},{trunk:0,support:'double',driver:{side:'left',joint:'toe',value:30}},{trunk:0,support:'double',driver:{side:'left',joint:'hip',value:NaN}},{trunk:0,support:'double',driver:{side:'left',joint:'hip',value:'30'}},{trunk:0,support:'double',driver:{side:'left',joint:'hip'}}];
 const solver=createConstraintSolver();for(const input of invalid)assert.throws(()=>solver.solve(input),`invalid input accepted: ${JSON.stringify(input)}`);const result=solver.solve({trunk:0,support:'double'});assertRenderedFeasible(result);return {rejectedCases:invalid.length};
});

// A CanvasTexture needs only this drawing surface; there is no WebGL mock and
// all actual bone matrices, skinned mesh data and model.update code run normally.
globalThis.document={createElement(tag){assert.equal(tag,'canvas');return{width:0,height:0,getContext(){return{fillRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){}}}}}};
function weightedVertex(mesh,i){
 const g=mesh.geometry,p=new THREE.Vector3().fromBufferAttribute(g.attributes.position,i).applyMatrix4(mesh.bindMatrix),result=vec(),matrix=new THREE.Matrix4();
 for(let k=0;k<4;k++){const weight=g.attributes.skinWeight.getComponent(i,k);if(!weight)continue;const id=g.attributes.skinIndex.getComponent(i,k);matrix.multiplyMatrices(mesh.skeleton.bones[id].matrixWorld,mesh.skeleton.boneInverses[id]);result.addScaledVector(p.clone().applyMatrix4(matrix),weight);}
 return result.applyMatrix4(mesh.bindMatrixInverse).applyMatrix4(mesh.matrixWorld);
}
for(const low of [true,false]){
 const model=createAnatomy(new THREE.Scene(),{low}),soleVertices={left:[],right:[]};
 for(const mesh of [model.meshBones,model.meshMuscles]){
  const {position,skinIndex,skinWeight}=mesh.geometry.attributes;
  for(let i=0;i<position.count;i++)if(position.getY(i)<.033){
   const sideWeights={left:0,right:0};for(let k=0;k<4;k++){const id=skinIndex.getComponent(i,k);if([7,8].includes(id))sideWeights.left+=skinWeight.getComponent(i,k);if([11,12].includes(id))sideWeights.right+=skinWeight.getComponent(i,k);}
   for(const side of ['left','right'])if(sideWeights[side]>=.5)soleVertices[side].push({mesh,index:i,bind:new THREE.Vector3().fromBufferAttribute(position,i)});
  }
 }
 const scenarios=[{trunk:0,support:'double'}, {trunk:35,support:'double'},{trunk:0,support:'left'},{trunk:0,support:'right'}, {trunk:0,support:'double',driver:{side:'left',joint:'knee',value:30}}, {trunk:0,support:'double',driver:{side:'left',joint:'knee',value:140}}, {trunk:35,support:'left',driver:{side:'left',joint:'hip',value:85}}, {trunk:-10,support:'left',driver:{side:'left',joint:'knee',value:140}}];
 for(const input of scenarios)test(`Real ${low?'low':'high'} mesh integration ${JSON.stringify(input)}`,()=>{
  model.update({mode:'constraint',...input});const result=model.constraintResult;const actualTrunk=result.actualTrunk??result.trunk??input.trunk;model.constraintSolver.apply(result.q,actualTrunk);
  let transformError=0;for(let i=0;i<model.bones.length;i++)transformError=Math.max(transformError,maxDelta(model.bones[i].matrixWorld.elements,model.constraintSolver.bones[i].matrixWorld.elements));assert.ok(transformError<1e-13,`actual and solver bone-world transform mismatch ${transformError}`);
  const footStats={};
  for(const side of ['left','right']){
   assert.ok(soleVertices[side].length>0,'real sole samples exist');let minY=Infinity,maxDisplacement=0,maxSkinningError=0;
   for(const {mesh,index,bind} of soleVertices[side]){const point=weightedVertex(mesh,index);minY=Math.min(minY,point.y);maxDisplacement=Math.max(maxDisplacement,point.distanceTo(bind));const expected=bind.clone();mesh.applyBoneTransform(index,expected);expected.applyMatrix4(mesh.matrixWorld);maxSkinningError=Math.max(maxSkinningError,point.distanceTo(expected));}
   assert.ok(maxSkinningError<1e-13,'independent four-weight skinning disagrees with THREE');
   assert.ok(minY>=-.001,`real ${side} foot penetrates floor: ${minY} m`);
   if(supportSides(input.support).includes(side)){assert.ok(minY<.02,`real support foot is not near floor: ${minY} m`);assert.ok(maxDisplacement<.003,`real support sole slips ${maxDisplacement} m`);}else assert.ok(minY>.02,`real swing foot does not clear floor: ${minY} m`);
   footStats[side]={vertexCount:soleVertices[side].length,minHeightMeters:minY,maxBindDisplacementMeters:maxDisplacement,maxSkinningError};
  }
  const row={quality:low?'low':'high',input,status:result.status,maxBoneWorldTransformError:transformError,feet:footStats};integration.push(row);assertRenderedFeasible(result);
  const cached=result;model.update({mode:'constraint',...input});assert.equal(model.constraintResult,cached,'same state should reuse constraint result');return row;
 });
}
const failures=tests.filter(t=>t.status==='failed');
const sourceHashes=Object.fromEntries(['src/constraints.js','src/model.js','src/anatomy/coherent-data.js','scripts/test-constraints.mjs'].map(file=>[file,createHash('sha256').update(fs.readFileSync(path.join(directory,file))).digest('hex')]));
const report={status:failures.length?'failed':'passed',generatedAt:new Date().toISOString(),command:'node scripts/test-constraints.mjs',sourceHashes,scope:'Independent numerical invariants plus createAnatomy integration and four-weight skinning of both resolution meshes. No browser-rendering or clinical validation claim.',tolerances:{supportFootMeters:.001,supportRotationDegrees:1,negativeStabilityMarginMeters:.0001,swingClearanceMeters:.02,rigidSegmentLengthMeters:2e-14,forceNewtons:1e-9,momentNewtonMeters:1e-9,weightedSoleFloorMeters:[-.001,.02],weightedSoleSlipMeters:.003},limitations:['Patella attachment offsets intentionally translate with knee flexion; rigid-length checks cover all other hierarchy segments.','Foot contact is an explicit 7 mm-high rectangular proxy, while actual weighted skinned sole geometry is separately tested.','Generic quasi-static mass and vertical reactions are not measured subject-specific biomechanics.'],testCount:tests.length,passed:tests.length-failures.length,failed:failures.length,failures,tests,cases,integration};
fs.writeFileSync(path.join(directory,'QA-constraints-unit.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,tests:report.testCount,passed:report.passed,failed:report.failed,report:'QA-constraints-unit.json',failures:failures.map(({name,message})=>({name,message}))},null,2));
if(failures.length)process.exitCode=1;
