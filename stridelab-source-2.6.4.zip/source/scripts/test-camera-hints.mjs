// Production hint/mode functions with DOM/media-query stubs; no physical device or browser layout simulated.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import * as THREE from 'three';
const root = new URL('../', import.meta.url);
const source = fs.readFileSync(new URL('src/app.js', root), 'utf8');
const template = fs.readFileSync(new URL('index.template.html', root), 'utf8');
const hintStart = source.indexOf('let cameraInput=');
const hintEnd = source.indexOf('\nfunction setView(', hintStart);
assert(hintStart >= 0 && hintEnd > hintStart, 'Could not extract production camera hint/mode functions');
const hintSource = source.slice(hintStart, hintEnd);
const globalBindings = source.slice(source.indexOf('\nfunction setView('), source.indexOf("\n$('#trunk').value="));
const modeBinding = globalBindings.match(/^\$\$\('\[data-camera-mode\]'\)\.forEach\(b=>b\.onclick=\(\)=>setCameraMode\(b\.dataset\.cameraMode\)\);$/m)?.[0];
assert(modeBinding, 'Mode-button listeners must be installed during global initialization');
let checks = 0;
const check = (value, message) => { assert(value, message); checks++; };
function setup(coarse = false, renderMode = 'webgl') {
  const elements = new Map();
  const element = selector => {
    if (!elements.has(selector)) elements.set(selector, {
      textContent: '', attributes: {}, dataset: {}, classes: new Set(),
      setAttribute(k, v) { this.attributes[k] = v; },
      classList: { toggle() {} },
    });
    return elements.get(selector);
  };
  const buttons = ['rotate', 'pan'].map(mode => {
    const b = element(`[data-camera-mode=${mode}]`); b.dataset.cameraMode = mode;
    b.classList.toggle = (name, active) => active ? b.classes.add(name) : b.classes.delete(name);
    return b;
  });
  const ctx = {
    THREE, matchMedia: () => ({ matches: coarse }), state: { renderMode }, $: element,
    $$: selector => selector === '[data-camera-mode]' ? buttons : [],
    text: (s, v) => element(s).textContent = v,
    model: { select: id => id ? { label: '测试肌肉', name: 'Test muscle' } : null }, dirty: false,
    orbit: { mouseButtons: {}, touches: {} },
  };
  vm.createContext(ctx);
  vm.runInContext(hintSource + ';this.select=select;this.updateCameraHint=updateCameraHint;this.setCameraMode=setCameraMode;', ctx);
  vm.runInContext(modeBinding, ctx);
  buttons[0].onclick(); ctx.select(null);
  return { ctx, element, buttons };
}
for (const renderMode of ['webgl', 'canvas']) for (const coarse of [false, true]) {
  const { ctx, element, buttons } = setup(coarse, renderMode);
  for (const mode of ['rotate', 'pan', 'rotate']) for (const input of ['mouse', 'touch', 'pen']) {
    buttons.find(button => button.dataset.cameraMode === mode).onclick(); ctx.updateCameraHint(input);
    const action = mode === 'pan' ? '平移' : '旋转';
    const hint = input === 'touch' ? `单指拖动${action} · 双指缩放` : `左键拖动${action} · 滚轮缩放`;
    const label = `${renderMode}, coarse=${coarse}, ${mode}, ${input}`;
    check(element('#muscle-description').textContent.endsWith(hint), label + ' current description');
    check(element('#camera-gesture').textContent === hint, label + ' always-visible hint');
    check(element('#viewport').attributes['aria-label'].includes(hint), label + ' accessible hint');
    check(element('#viewport').dataset.cameraMode === mode, label + ' cursor mode attribute');
    check(element('#muscle-description').textContent.startsWith('兼容绘制') === (renderMode === 'canvas'), label + ' compatibility notice');
    check(element('#camera-help').textContent.includes('“旋转”或“平移”'), label + ' explains toggle');
    check(element('#camera-help').textContent.includes(input === 'touch' ? '双指缩放或平移' : '右键平移'), label + ' alternative gestures');
    check(!hint.includes(input === 'touch' ? '滚轮' : '双指'), label + ' does not mix device instructions');
    for (const button of buttons) {
      check(button.attributes['aria-pressed'] === String(button.dataset.cameraMode === mode), label + ' pressed semantics');
      check(button.classes.has('active') === (button.dataset.cameraMode === mode), label + ' active styling');
    }
    ctx.select('muscle'); ctx.setCameraMode(mode === 'pan' ? 'rotate' : 'pan'); ctx.updateCameraHint(input);
    check(element('#muscle-description').textContent === 'Test muscle', label + ' preserves selected muscle name');
    ctx.select(null);
    check(element('#muscle-description').textContent.endsWith(element('#camera-gesture').textContent), label + ' deselection restores latest mode');
  }
  ctx.setCameraMode('invalid');
  check(element('#viewport').dataset.cameraMode === 'rotate', renderMode + ' invalid mode falls back to rotate');
}
const touch = setup(true);
check(touch.element('#muscle-description').textContent.includes('单指拖动旋转 · 双指缩放'), 'coarse pointer initially gets touch hint');
check(template.includes('<li id="camera-help">'), 'help target exists');
check(template.includes('id="camera-gesture"'), 'always-visible gesture target exists');
check(template.includes('data-camera-mode="rotate"') && template.includes('data-camera-mode="pan"'), 'both named drag options exist');
check(/role="group" aria-label="拖动方式"/.test(template), 'camera-mode group has accessible label');
check(template.includes('<span class="dimension-label">3D / 2D</span>'), 'header spells literal 2D');
check(!/<span class="dimension-label">[^<]*20/.test(template), 'header does not spell 20');
check(source.includes("canvas.addEventListener('pointerdown',e=>updateCameraHint(e.pointerType));"), 'actual pointer chooses hints');
check(source.includes("canvas.addEventListener('wheel',()=>updateCameraHint('mouse'),{passive:true});"), 'wheel switches hybrid hint without replacing controls');
check(source.includes("$$('[data-camera-mode]').forEach(b=>b.onclick=()=>setCameraMode(b.dataset.cameraMode));"), 'mode buttons invoke production handler');
check(source.includes("$('#reset-view').onclick=()=>setView('perspective');"), 'view reset invokes perspective preset');
check(/bindCanvasPicking\(canvas,e=>\{.*?model\.hit\(p,camera\);select\(h\?\.id\?\?null\);\}\);/.test(source), 'production initialization binds guarded picking to hit/select');
console.log('PASS', checks, 'camera hint, mode UI and literal-header checks');
