// Production gesture hints with DOM/media-query stubs; no physical device or browser layout simulated.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const root = new URL('../', import.meta.url);
const source = fs.readFileSync(new URL('src/app.js', root), 'utf8');
const template = fs.readFileSync(new URL('index.template.html', root), 'utf8');
const hintStart = source.indexOf('let cameraInput=');
const hintEnd = source.indexOf('\nfunction setView(', hintStart);
assert(hintStart >= 0 && hintEnd > hintStart, 'Could not extract production camera hint functions');
const hintSource = source.slice(hintStart, hintEnd);
const desktopHint = '左键拖动旋转 · 右键拖动平移 · 滚轮缩放';
const touchHint = '单指拖动旋转 · 双指缩放或平移';
let checks = 0;
const check = (value, message) => { assert(value, message); checks++; };
function setup(coarse = false, renderMode = 'webgl') {
  const elements = new Map();
  const element = selector => {
    if (!elements.has(selector)) {
      const classes = new Set();
      elements.set(selector, {
        textContent: '', attributes: {}, dataset: {}, classes,
        setAttribute(k, v) { this.attributes[k] = v; },
        classList: { toggle: (name, active) => active ? classes.add(name) : classes.delete(name) },
      });
    }
    return elements.get(selector);
  };
  const ctx = {
    matchMedia: () => ({ matches: coarse }), state: { renderMode }, $: element,
    $$: () => [], text: (s, v) => element(s).textContent = v,
    model: { select: id => id ? { label: '测试肌肉', name: 'Test muscle' } : null }, dirty: false,
  };
  vm.createContext(ctx);
  vm.runInContext(hintSource + ';this.select=select;this.updateCameraHint=updateCameraHint;', ctx);
  ctx.select(null);
  return { ctx, element };
}
for (const renderMode of ['webgl', 'canvas']) for (const coarse of [false, true]) {
  const { ctx, element } = setup(coarse, renderMode);
  check(element('#camera-gesture').textContent === (coarse ? touchHint : desktopHint), `${renderMode} initial device hint`);
  for (const input of ['mouse', 'touch', 'pen', 'mouse', 'touch']) {
    ctx.updateCameraHint(input);
    const hint = input === 'touch' ? touchHint : desktopHint;
    const label = `${renderMode}, coarse=${coarse}, ${input}`;
    check(element('#muscle-description').textContent.endsWith(hint), label + ' current description');
    check(element('#camera-gesture').textContent === hint, label + ' always-visible direct gesture hint');
    check(element('#viewport').attributes['aria-label'].includes(hint), label + ' accessible hint');
    check(!Object.hasOwn(element('#viewport').attributes, 'aria-pressed'), label + ' viewport has no button pressed semantics');
    check(!element('#viewport').classes.has('active'), label + ' viewport has no active button styling');
    check(element('#viewport').onclick == null, label + ' viewport has no mode-button click handler');
    check(!Object.hasOwn(element('#viewport').dataset, 'cameraMode'), label + ' viewport has no mode state');
    check(element('#muscle-description').textContent.startsWith('兼容绘制') === (renderMode === 'canvas'), label + ' compatibility notice');
    check(!element('#camera-help').textContent.includes('点选“旋转”或“平移”'), label + ' no toggle instructions');
    check(element('#camera-help').textContent.includes(input === 'touch' ? '双指缩放或平移' : '右键'), label + ' direct pan instructions');
    check(!hint.includes(input === 'touch' ? '滚轮' : '双指'), label + ' does not mix device instructions');
    ctx.select('muscle'); ctx.updateCameraHint(input === 'touch' ? 'mouse' : 'touch');
    check(element('#muscle-description').textContent === 'Test muscle', label + ' preserves selected muscle name');
    ctx.select(null);
    check(element('#muscle-description').textContent.endsWith(element('#camera-gesture').textContent), label + ' deselection restores latest device hint');
  }
}
check(template.includes('<li id="camera-help">'), 'help target exists');
check(template.includes('id="camera-gesture"'), 'always-visible gesture target exists');
check(template.includes(desktopHint), 'initial markup lists all three direct mouse gestures');
check(!template.includes('data-camera-mode'), 'no camera mode buttons in template');
check(!template.includes('camera-modes'), 'no camera mode toolbar in template');
check(!source.includes('setCameraMode') && !source.includes('cameraMode') && !source.includes('data-camera-mode'), 'production has no camera-mode state or bindings');
check(template.includes('<span class="dimension-label">3D / 2D</span>'), 'header spells literal 2D');
check(!/<span class="dimension-label">[^<]*20/.test(template), 'header does not spell 20');
check(source.includes("canvas.addEventListener('pointerdown',e=>updateCameraHint(e.pointerType));"), 'actual pointer chooses hints');
check(source.includes("canvas.addEventListener('wheel',()=>updateCameraHint('mouse'),{passive:true});"), 'wheel switches hybrid hint without replacing controls');
check(source.includes("$('#reset-view').onclick=()=>setView('perspective');"), 'view reset invokes perspective preset');
check(/bindCanvasPicking\(canvas,e=>\{.*?model\.hit\(p,camera\);select\(h\?\.id\?\?null\);\}\);/.test(source), 'production initialization binds guarded picking to hit/select');
console.log('PASS', checks, 'direct camera hint, no-toggle UI and literal-header checks');
