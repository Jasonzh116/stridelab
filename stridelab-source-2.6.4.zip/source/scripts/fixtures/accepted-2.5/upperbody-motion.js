// Authored running coordination, NOT RBDS upper-body measurements or dynamics.
// Inspect actual shoulder-relative wrist paths: local joint excursion alone can
// hide a rigid-looking arm when shoulder and elbow changes cancel in world space.
import * as THREE from 'three';
import {referenceGait} from './motion-reference.js';
const D=Math.PI/180,mod=p=>(p%1+1)%1;
const softplus=x=>x>30?x:Math.log1p(Math.exp(x));
const bounded=(x,lo,hi)=>lo+3*softplus((x-lo)/3)-3*softplus((x-hi)/3);
// Periodic shape-preserving key poses with continuous velocity; only true directional reversals stop. They describe an
// authored hand-to-hip / hand-to-chest arc, not digit or recorded marker motion.
const shoulderKeys=[[0,28],[.16,5],[.35,-23],[.48,-10],[.65,23],[.82,47],[1,28]];
const elbowKeys=[[0,82],[.18,96],[.38,105],[.58,91],[.82,74],[1,82]];
function makeCurve(keys){const k=keys.slice(0,-1),n=k.length,m=k.map(([p,x],i)=>{const prev=k[(i+n-1)%n],next=k[(i+1)%n],h0=p-(prev[0]-(i===0?1:0)),h1=next[0]+(i===n-1?1:0)-p,a=(x-prev[1])/h0,b=(next[1]-x)/h1;if(a*b<=0)return 0;const w0=2*h1+h0,w1=h1+2*h0;return(w0+w1)/(w0/a+w1/b)});return phase=>{const p=mod(phase);let i=0;while(i<n-1&&p>k[i+1][0])i++;const j=(i+1)%n,a=k[i][0],b=j===0?1:k[j][0],h=b-a,t=(p-a)/h,x=k[i][1],y=k[j][1];return(2*t**3-3*t*t+1)*x+(t**3-2*t*t+t)*h*m[i]+(-2*t**3+3*t*t)*y+(t**3-t*t)*h*m[j]};}
const shoulderCurve=makeCurve(shoulderKeys),elbowCurve=makeCurve(elbowKeys);
export const upperBodyAssumptions={source:'illustrative authored hand-arc coordination; not measured RBDS upper-body data or angular-momentum dynamics',chestYawBoundDegrees:10,chestRollAmplitudeDegrees:2.5,chestPitchAmplitudeDegrees:2,shoulderExtensionBoundsDegrees:[-30,58],elbowFlexionBoundsDegrees:[65,118],headCounterRotation:true};
export function upperBodyPose(phase,speed,leftWorldHipRadians,rightWorldHipRadians){
 const t=2*Math.PI*mod(phase),s=Math.max(0,Math.min(1,(speed-2.5)/2)),arms={};
 for(const[side,sign,actual]of[['left',1,leftWorldHipRadians],['right',-1,rightWorldHipRadians]]){
  const p=mod(phase+(side==='right'?.5:0)),angle=p*2*Math.PI,delta=actual/D-referenceGait(p,'hip',speed);
  const excursion=shoulderCurve(p),extension=bounded(10+(excursion-10)*(1+.13*s)+.45*delta,-30,58);
  arms[side]={extension,abduction:-2+1.5*Math.sin(angle-.3),axial:-sign*(10+4*Math.sin(angle-.2)),elbow:bounded(elbowCurve(p)-.16*delta+2*s,65,118),pronation:66+4*Math.sin(angle+.25),wristPitch:3+2*Math.sin(angle+.45)};
 }
 // Chest turning follows the actual opposing arm excursions rather than an
 // unrelated oscillation; edits therefore influence upper-body coordination.
 const chestYaw=bounded((arms.left.extension-arms.right.extension)*.13,-10,10),chestRoll=-(1.7+.4*s)*Math.sin(t),chestPitch=(1.4+.3*s)*Math.cos(2*t+.4);
 return{chestYaw,chestRoll,chestPitch,arms};
}
export function createUpperBodyMotion(byName){
 const twist=new THREE.Quaternion(),axes={L:byName.wristL.position.clone().normalize(),R:byName.wristR.position.clone().normalize()};
 return function applyUpperBody(phase,speed,leftWorldHipRadians,rightWorldHipRadians){
  const pose=upperBodyPose(phase,speed,leftWorldHipRadians,rightWorldHipRadians);
  byName.lumbar.rotation.y=pose.chestYaw*.30*D;byName.thorax.rotation.y=pose.chestYaw*.70*D;
  byName.lumbar.rotation.z=pose.chestRoll*.4*D;byName.thorax.rotation.z=pose.chestRoll*.6*D;
  byName.lumbar.rotation.x+=pose.chestPitch*.3*D;byName.thorax.rotation.x+=pose.chestPitch*.7*D;
  byName.head.rotation.y=-pose.chestYaw*.6*D;byName.head.rotation.z=-pose.chestRoll*.7*D;byName.head.rotation.x-=pose.chestPitch*.5*D;
  for(const[side,s,sign]of[['left','L',1],['right','R',-1]]){const a=pose.arms[side];
   byName['shoulder'+s].rotation.set(a.extension*D,a.axial*D,sign*a.abduction*D);
   byName['elbow'+s].rotation.x=-a.elbow*D;
   byName['elbow'+s].quaternion.multiply(twist.setFromAxisAngle(axes[s],sign*a.pronation*D));
   byName['wrist'+s].rotation.x=a.wristPitch*D;
  }
  return pose;
 };
}
