export{anatomyPackage}from'../../../../../src/anatomy/coherent-data.js';
