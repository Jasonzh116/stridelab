"""Read-only hand triangle contact screening; requires numpy, scipy, vtk.
python test-fist-clearance.py --repo REPO --out OUTPUT
Uses actual packed high/low source meshes. Not a soft-tissue/clinical validation.
"""
import argparse,json,base64,gzip,hashlib
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
import vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray,vtk_to_numpy
ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,default=Path.cwd());ap.add_argument('--out',type=Path,default=Path.cwd());args=ap.parse_args();root=args.repo;args.out.mkdir(parents=True,exist_ok=True);vtk.vtkObject.GlobalWarningDisplayOff()
s=(root/'src/anatomy/coherent-data.js').read_text();pkg=json.loads(s[s.index('=')+1:].strip().rstrip(';'));rig=json.loads((root/'model-assets/hand-rig.json').read_text());raw=json.loads((root/'model-assets/coherent-optimized.json').read_text());nodes=pkg['nodes'];bind=np.array([n['p']for n in nodes])
def unpack(lod):
 d=pkg[lod]['bone'];b=gzip.decompress(base64.b64decode(d['data']));n=d['count'];p=np.frombuffer(b,dtype='<u2',count=n*3).reshape(n,3)/65535*np.array(d['extent'])+np.array(d['min']);ix=np.frombuffer(b,dtype='u1',count=n*4,offset=n*6).reshape(n,4);f=np.frombuffer(b,dtype='<u4',offset=n*17).reshape(-1,3);return p,ix,f
local=np.repeat(np.eye(4)[None],len(nodes),0)
for i,n in enumerate(nodes):local[i,:3,3]=bind[i]-(bind[n['parent']]if n['parent']>=0 else 0)
for d in rig['digits']:
 flex=Rotation.from_rotvec(np.array(d['flexAxis'])*np.deg2rad(d['flexDegrees']));splay=Rotation.from_rotvec(np.array(d['splayAxis'])*np.deg2rad(d['splayDegrees']));local[d['index'],:3,:3]=(splay*flex).as_matrix()
world=local.copy()
for i,n in enumerate(nodes):
 if n['parent']>=0:world[i]=world[n['parent']]@local[i]
inverse=np.repeat(np.eye(4)[None],len(nodes),0);inverse[:,:3,3]=-bind;mats=world@inverse

def poly(p,f,normals=False):
 o=vtk.vtkPolyData();pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(np.array(p,dtype=np.float64),deep=True));o.SetPoints(pts);cells=vtk.vtkCellArray();cells.SetCells(len(f),numpy_to_vtkIdTypeArray(np.c_[np.full(len(f),3),f].astype(np.int64).ravel(),deep=True));o.SetPolys(cells)
 if normals:
  n=vtk.vtkPolyDataNormals();n.SetInputData(o);n.AutoOrientNormalsOn();n.ConsistencyOn();n.Update();return n.GetOutput()
 return o

def structures(lod,side):
 p,ids,faces=unpack(lod);result=[];off=0;ordinals={'first':1,'second':2,'third':3,'fourth':4,'fifth':5}
 for o in raw:
  if o['kind']!='bone':continue
  start=off
  for part in o['parts']:
   pp=np.array(part['positions']);fs=np.array(part['indices'])
   if lod=='low'and len(fs)>12:
    dec=vtk.vtkQuadricDecimation();dec.SetInputData(poly(pp,fs));dec.SetTargetReduction(1-max(6,int(len(fs)*.025))/len(fs));dec.Update();po=dec.GetOutput()
    if po.GetNumberOfPoints()>0:pp=vtk_to_numpy(po.GetPoints().GetData())
   # Reproduce source partition and independently check packed coordinates.
   count=len(pp);tol=max(pkg[lod]['bone']['extent'])/65535*1.1
   assert np.max(abs(pp-p[off:off+count]))<=tol,(lod,o['name'],'partition mismatch');off+=count
  end=off;name=o['name'];lo=name.lower()
  if name.endswith('.'+side.lower())and('hand'in lo or'metacarpal'in lo):
   fs=faces[np.all((faces>=start)&(faces<end),axis=1)]-start;digit=next(v for k,v in ordinals.items()if k in lo);joint=0 if'metacarpal'in lo else 1 if lo.startswith('proximal')else 2 if lo.startswith('middle')or digit==1 else 3;bone=int(ids[start,0]);assert np.all(ids[start:end,0]==bone)
   pts=(np.c_[p[start:end],np.ones(end-start)]@mats[bone].T)[:,:3];po=poly(pts,fs,True);dist=vtk.vtkImplicitPolyDataDistance();dist.SetInput(po);samples=np.r_[pts,pts[fs].mean(1)];result.append(dict(name=name,digit=digit,joint=joint,poly=po,distance=dist,samples=samples))
 assert off==len(p);return result

def gap(a,b):return min(abs(b['distance'].EvaluateFunction(x))for x in a['samples'])
def contact(a,b):
 f=vtk.vtkCollisionDetectionFilter();f.SetInputData(0,a['poly']);f.SetInputData(1,b['poly']);t=vtk.vtkTransform();f.SetTransform(0,t);f.SetTransform(1,t);f.SetBoxTolerance(0);f.SetCellTolerance(0);f.SetCollisionModeToAllContacts();f.Update();return f.GetNumberOfContacts()
report={'method':'Actual packed bone surfaces, VTK zero-tolerance triangle contacts and unsigned vertex/face-centroid-to-triangle sampled clearances. Adjacent same-digit articulations and unchanged metacarpal pairs excluded. Source winding is unsuitable for signed volume clearance. Fixed digit pose means these hand-only pair distances are invariant under the shared wrist rigid transform through swing. Not a proof of exact minimum distance, tendon/palm soft-tissue separation or physiological realism.','versions':{'numpy':np.__version__,'vtk':vtk.vtkVersion.GetVTKVersion()},'sourceSHA256':{f:hashlib.sha256((root/f).read_bytes()).hexdigest()for f in ['src/anatomy/coherent-data.js','model-assets/hand-rig.json','model-assets/coherent-optimized.json']},'results':{}}
for lod in ['high','low']:
 for side in ['L','R']:
  ps=structures(lod,side);rows=[]
  for i,a in enumerate(ps):
   for b in ps[i+1:]:
    if a['joint']==b['joint']==0:continue
    if a['digit']==b['digit']and abs(a['joint']-b['joint'])==1:continue
    rows.append({'a':a['name'],'b':b['name'],'contacts':contact(a,b),'sampledClearanceMm':1000*min(gap(a,b),gap(b,a))})
  coll=[x for x in rows if x['contacts']];report['results'][lod+side]={'pairs':len(rows),'collisions':coll,'minimumSampledClearanceMm':min(x['sampledClearanceMm']for x in rows),'rows':rows};print(lod,side,'contacts',len(coll),'minimum sampled clearance mm',report['results'][lod+side]['minimumSampledClearanceMm'])
report['status']='failed'if any(r['collisions']for r in report['results'].values())else'passed';(args.out/'QA-fist-clearance.json').write_text(json.dumps(report,indent=2))
if report['status']!='passed':raise SystemExit(1)
