// Exercise the production UI update and click handler; no renderer is simulated.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const root = new URL('../', import.meta.url);
const source = fs.readFileSync(new URL('src/app.js', root), 'utf8');
const template = fs.readFileSync(new URL('index.template.html', root), 'utf8');
const updateSource = source.split('\n').find(line => line.startsWith('function updateUI(){'));
const clickSource = source.match(/\$\('#play'\)\.onclick=(\(\)=>\{.*?\});\$\('#phase'\)/)?.[1];
assert(updateSource && clickSource);
const elements = new Map();
const element = selector => {
  if (!elements.has(selector)) elements.set(selector, {
    innerHTML: '', textContent: '', attributes: {}, writes: 0,
    setAttribute(name, value) { this.attributes[name] = value; }
  });
  return elements.get(selector);
};
let iconMarkup = '';
Object.defineProperty(element('#play-icon'), 'innerHTML', {
  get() { return iconMarkup; },
  set(value) { iconMarkup = value; this.writes++; }
});
const ctx = {
  state: { playing: true, ready: true, mode: 'run', renderMode: 'canvas', phase: 0 },
  uiCache: {}, $: element, updateConstraintUI() {}, visibleDefinitions: () => ({}),
  text(selector, value) { element(selector).textContent = value; },
  renderControls() {}, pose() { ctx.updateUI(); }
};
vm.createContext(ctx);
vm.runInContext(updateSource + ';this.updateUI=updateUI;', ctx);
const click = vm.runInContext('(' + clickSource + ')', ctx);
let checks = 0;
function check(condition, message) { assert(condition, message); checks++; }
ctx.updateUI();
const pause = iconMarkup;
const rectangles = [...pause.matchAll(/<rect\b([^>]*)\/>/g)].map(match =>
  Object.fromEntries([...match[1].matchAll(/(\w+)="([^"]*)"/g)].map(([, key, value]) => [key, +value]))
);
check(rectangles.length === 2, 'Pause has exactly two rectangles');
check(rectangles.every(r => r.height > r.width && r.width > 0), 'Pause bars are vertical');
check(rectangles[0].x + rectangles[0].width < rectangles[1].x, 'Pause bars are separate');
check(!/[Ⅱ‖]/u.test(pause), 'Pause uses no font glyph');
check(template.includes('<span id="play-icon" aria-hidden="true">' + pause + '</span>'), 'Initial markup matches playing SVG');
check(element('#play').attributes['aria-label'] === '暂停', 'Playing action stays accessible');
const writes = element('#play-icon').writes;
ctx.updateUI();
check(element('#play-icon').writes === writes, 'Stable state does not rebuild the icon');
click();
check(!ctx.state.playing && iconMarkup === '▶︎', 'Click pauses and preserves play glyph');
check(element('#play').attributes['aria-label'] === '播放', 'Paused action stays accessible');
click();
check(ctx.state.playing && iconMarkup === pause, 'Click resumes and restores the pause bars');
for (let i = 0; i < 6; i++) click();
check(ctx.state.playing && iconMarkup === pause, 'Repeated clicks retain correct state');
ctx.state.ready = false;
click();
check(ctx.state.playing, 'Not-ready click guard is unchanged');
ctx.state.ready = true;
ctx.state.mode = 'pose';
ctx.state.playing = false;
click();
check(ctx.state.mode === 'run' && ctx.state.playing && iconMarkup === pause, 'Play from pose returns to running');
ctx.state.playing = false;
ctx.uiCache = {};
ctx.updateUI();
check(iconMarkup === '▶︎', 'Initially paused or reduced-motion state uses play glyph');
console.log('PASS', checks, 'playback icon/state checks');
