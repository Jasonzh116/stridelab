// Real Three.js OrbitControls + production direct camera/view/hint/loop functions and
// imported production canvas picking. Synthetic DOM/input/rAF; render dispatch is
// stubbed. This does not claim browser pointer routing or physical-device coverage.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { bindCanvasPicking, configureBrowserSafeCamera } from '../src/camera-input.js';
const root = new URL('../', import.meta.url);
const source = fs.readFileSync(new URL('src/app.js', root), 'utf8');
function extract(pattern, name) {
  const result = source.match(pattern)?.[0];
  assert(result, `Could not extract production ${name}; update harness if structure changed`);
  return result;
}
const stateSource = extract(/^const state=.*;$/m, 'state');
const cameraSource = extract(/camera=new THREE\.PerspectiveCamera\([^;]+\);/, 'camera');
const targetSource = extract(/target=new THREE\.Vector3\([^;]+\);/, 'target');
const setupSource = extract(/orbit=new OrbitControls\(camera,canvas\);[\s\S]*?setView\('perspective'\);/, 'controls setup');
const hintSource = source.slice(source.indexOf('let cameraInput='), source.indexOf('\nfunction setView('));
const viewSource = extract(/^function setView\(name\).*$/m, 'setView');
const loopSource = extract(/^function loop\(now\).*$/m, 'loop');
const pickingSource = extract(/bindCanvasPicking\(canvas,e=>\{.*?model\.hit\(p,camera\);select\(h\?\.id\?\?null\);\}\);/, 'initialization of guarded picking');

class EventSurface {
  constructor() {
    this.listeners = new Map(); this.style = {}; this.dataset = {}; this.attributes = {};
    this.clientWidth = 1000; this.clientHeight = 700; this.captures = new Set(); this.captureCalls = []; this.classes = new Set();
    this.classList = {
      add: name => this.classes.add(name), remove: name => this.classes.delete(name), contains: name => this.classes.has(name),
      toggle: (name, on = !this.classes.has(name)) => on ? this.classes.add(name) : this.classes.delete(name),
    };
  }
  addEventListener(type, listener, options = {}) {
    const entries = this.listeners.get(type) || [];
    if (!entries.some(entry => entry.listener === listener)) entries.push({ listener, options });
    this.listeners.set(type, entries);
  }
  removeEventListener(type, listener) { this.listeners.set(type, (this.listeners.get(type) || []).filter(entry => entry.listener !== listener)); }
  dispatch(type, values = {}) {
    const event = { type, target: this, defaultPrevented: false, ...values };
    let options = {};
    event.preventDefault = () => { if (!options.passive) event.defaultPrevented = true; };
    event.stopPropagation = () => { event.propagationStopped = true; };
    event.stopImmediatePropagation = () => { event.propagationStopped = true; event.immediatePropagationStopped = true; };
    for (const entry of [...(this.listeners.get(type) || [])]) { if (event.immediatePropagationStopped) break; options = entry.options; entry.listener(event); }
    return event;
  }
  getRootNode() { return this.root || this; }
  getBoundingClientRect() { return { left: 20, top: 30, right: 1020, bottom: 730, width: this.clientWidth, height: this.clientHeight }; }
  setPointerCapture(id) { this.captureCalls.push(id); this.captures.add(id); }
  releasePointerCapture(id) { this.captures.delete(id); }
  setAttribute(name, value) { this.attributes[name] = value; }
}
function setup({ renderMode = 'canvas', mode = 'run', wrongShiftPan = false, skipBrowserGuard = false } = {}) {
  const canvas = new EventSurface(), document = new EventSurface(), elements = new Map(); canvas.root = document; document.hidden = false;
  const element = selector => { if (!elements.has(selector)) elements.set(selector, new EventSurface()); return elements.get(selector); };
  const viewButtons = ['perspective', 'side', 'front'].map(view => { const b = new EventSurface(); b.dataset.view = view; return b; });
  const ctx = {
    THREE, OrbitControls, bindCanvasPicking, configureBrowserSafeCamera: skipBrowserGuard ? () => {} : configureBrowserSafeCamera, canvas, document, scene: new THREE.Scene(), dirty: true, lastTime: 0, lastDraw: 0, uiElapsed: 0,
    poses: 0, overlays: 0, draws: [], picks: [], model: { runningResult: { cycleSeconds: 0.78 }, select: id => id ? { name: id, label: id } : null },
    matchMedia: () => ({ matches: false }), $: element,
    $$: selector => selector === '[data-view]' ? viewButtons : [],
    text: (s, value) => { element(s).textContent = value; },
    pose() { ctx.poses++; ctx.dirty = true; }, updateUI() {}, drawConstraintOverlay() { ctx.overlays++; }, requestAnimationFrame() {},
  };
  vm.createContext(ctx);
  vm.runInContext(`${stateSource}\nthis.state=state;\n${cameraSource}\n${targetSource}\n${hintSource}\n${viewSource}\n${setupSource}\n${loopSource}`, ctx);
  if (wrongShiftPan) ctx.orbit.enablePan = false;
  ctx.state.ready = true; ctx.state.renderMode = renderMode; ctx.state.mode = mode; ctx.state.playing = false; ctx.state.phase = 0.37;
  ctx.model.hit = (point, camera) => { assert.equal(camera, ctx.camera); ctx.picks.push({ ndc: point.toArray() }); return { id: 'Test muscle' }; };
  vm.runInContext(pickingSource, ctx);
  const baselineMove = canvas.listeners.get('pointermove').length, baselineUp = canvas.listeners.get('pointerup').length;
  const sample = () => ({ position: ctx.camera.position.clone(), target: ctx.orbit.target.clone(), direction: ctx.camera.position.clone().sub(ctx.orbit.target), quaternion: ctx.camera.quaternion.clone(), distance: ctx.camera.position.distanceTo(ctx.orbit.target) });
  ctx.renderer = { render(...args) { assert.equal(args.length, renderMode === 'webgl' ? 2 : 0); ctx.draws.push(sample()); } };
  let now = 0;
  const tick = (count = 1) => { for (let i = 0; i < count; i++) ctx.loop(now += 1000 / 60); };
  const pointer = (type, { id = 1, x = 500, y = 350, pointerType = 'mouse', button = 0, ...extra } = {}) => {
    const held = canvas.captures.has(id);
    const event = canvas.dispatch(type, { pointerId: id, pointerType, pageX: x, pageY: y, clientX: x, clientY: y, button, ...extra });
    // Pointerup/cancel implicit release and lostcapture follow input dispatch.
    // Touch implicit capture is not emulated; browser routing is a separate QA layer.
    if (type === 'pointerup' || type === 'pointercancel') {
      canvas.releasePointerCapture(id);
      if (held) canvas.dispatch('lostpointercapture', { pointerId: id, pointerType });
    }
    return event;
  };
  const wheel = (deltaY, extra = {}) => canvas.dispatch('wheel', { deltaY, deltaMode: 0, ctrlKey: false, clientX: 500, clientY: 350, ...extra });
  const drag = ({ pointerType = 'mouse', button = 0, x = 570, y = 380, ...extra } = {}) => {
    pointer('pointerdown', { pointerType, button, ...extra }); pointer('pointermove', { pointerType, button, x, y, ...extra }); pointer('pointerup', { pointerType, button, x, y, ...extra });
  };
  const assertPaused = () => { assert.equal(ctx.state.phase, 0.37, 'camera must preserve paused gait phase'); assert.equal(ctx.state.playing, false); assert.equal(ctx.poses, 0); };
  const assertReleased = () => {
    assert.equal(canvas.captures.size, 0, 'pointer capture released'); assert.equal(canvas.classes.has('dragging'), false, 'drag cursor terminated');
    assert.equal(canvas.listeners.get('pointermove').length, baselineMove, 'temporary controls move listener removed');
    assert.equal(canvas.listeners.get('pointerup').length, baselineUp, 'temporary controls up listener removed');
  };
  tick(); ctx.draws.length = 0; ctx.overlays = 0;
  return { ctx, canvas, element, viewButtons, pointer, wheel, drag, tick, sample, assertPaused, assertReleased, dispose: () => ctx.orbit.dispose() };
}
const results = [];
function test(name, run) {
  try { run(); results.push({ name, status: 'passed' }); }
  catch (error) { results.push({ name, status: 'failed', error: error.message }); console.error(`FAIL ${name}\n${error.stack}`); }
}
const near = (a, b, message = 'values match') => assert(Math.abs(a - b) < 1e-9, `${message}: ${a} vs ${b}`);
const sameVector = (a, b, message = 'vectors match') => assert(a.distanceTo(b) < 1e-9, `${message}: ${a.toArray()} vs ${b.toArray()}`);
function changed(a, b, message = 'vectors differ') { assert(a.distanceTo(b) > 1e-5, message); }
function assertPan(before, after) {
  changed(before.target, after.target, 'pan translates target');
  sameVector(after.position.clone().sub(before.position), after.target.clone().sub(before.target), 'pan translates camera and target equally');
  sameVector(before.direction, after.direction, 'pan preserves viewing direction'); near(before.distance, after.distance, 'pan preserves zoom');
}
const desktopHint = '左键拖动旋转 · Shift+左键拖动平移 · 滚轮缩放';
function assertDirectBindings(h) {
  assert.deepEqual({ ...h.ctx.orbit.mouseButtons }, { LEFT: THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: null });
  assert.deepEqual({ ...h.ctx.orbit.touches }, { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN });
  const viewport = h.element('#viewport');
  assert.equal(Object.hasOwn(viewport.attributes, 'aria-pressed'), false);
  assert.equal(viewport.classes.has('active'), false);
  assert.equal(viewport.onclick == null, true);
  assert.equal(Object.hasOwn(viewport.dataset, 'cameraMode'), false);
}
const gestures = [
  { label: 'left mouse rotation', pointerType: 'mouse', button: 0, action: 'rotate' },
  { label: 'Shift+left mouse pan', pointerType: 'mouse', button: 0, shiftKey: true, action: 'pan' },
  { label: 'one-finger rotation', pointerType: 'touch', button: 0, action: 'rotate' },
];
for (const renderMode of ['canvas', 'webgl']) {
  test(`${renderMode}: direct gestures need no mode state or buttons`, () => {
    const h = setup({ renderMode }); assertDirectBindings(h);
    assert(!source.includes('setCameraMode') && !source.includes('data-camera-mode') && !source.includes('cameraMode'));
    h.dispose();
  });
  test(`${renderMode}: negative control detects disabled Shift+left panning`, () => {
    const h = setup({ renderMode, wrongShiftPan: true }), before = h.sample(); h.drag({ shiftKey: true });
    assert.throws(() => assertPan(before, h.sample()), /pan translates target/); h.dispose();
  });
  test(`${renderMode}: browser context menu remains untouched everywhere`, () => {
    const h = setup({ renderMode });
    assert.equal(h.canvas.dispatch('contextmenu').defaultPrevented, false, 'canvas leaves browser context menu available');
    assert.equal(h.ctx.document.dispatch('contextmenu').defaultPrevented, false, 'document retains normal context menu');
    assert.equal(h.element('#viewport').dispatch('contextmenu').defaultPrevented, false, 'non-canvas viewport retains normal context menu');
    assert.equal(new EventSurface().dispatch('contextmenu').defaultPrevented, false, 'unrelated content retains normal context menu');
    assert.equal(h.canvas.listeners.get('contextmenu')?.length || 0, 0, 'OrbitControls context menu interception removed');
    assert(!/(?:document|window)\s*\.\s*(?:addEventListener\(['"]contextmenu|oncontextmenu)/.test(source), 'no global context menu suppression');
    h.dispose();
  });
  test(`${renderMode}: negative control proves disabling RIGHT alone still captures and cancels contextmenu`, () => {
    const h = setup({ renderMode, skipBrowserGuard: true });
    assert.equal(h.ctx.orbit.mouseButtons.RIGHT, null);
    h.pointer('pointerdown', { button: 2 });
    assert(h.canvas.captureCalls.length > 0, 'unguarded OrbitControls captures even with RIGHT disabled');
    assert(h.canvas.dispatch('contextmenu').defaultPrevented, 'unguarded OrbitControls cancels contextmenu');
    h.pointer('pointerup', { button: 2 }); h.dispose();
  });
  for (const pointerType of ['mouse', 'pen']) for (const shiftKey of [false, true]) for (const ending of ['pointerup', 'pointercancel', 'outside-no-canvas-up']) {
    test(`${renderMode}: right ${pointerType}, shift=${shiftKey}, ${ending} stays browser-owned`, () => {
      const h = setup({ renderMode }), before = h.sample(); let externalDown = 0;
      h.canvas.addEventListener('pointerdown', () => { externalDown++; });
      const untouched = event => {
        assert.equal(event.defaultPrevented, false, 'browser gesture default is not canceled');
        assert(!event.propagationStopped && !event.immediatePropagationStopped, 'browser/extension listeners still receive events');
      };
      for (let i = 0; i < 3; i++) {
        untouched(h.pointer('pointerdown', { pointerType, button: 2, buttons: 2, shiftKey }));
        assert.equal(h.canvas.captureCalls.length, 0, 'right button must never request pointer capture');
        assert.equal(h.ctx.orbit._pointers.length, 0, 'right pointer is not tracked by OrbitControls');
        assert.equal(h.canvas.classes.has('dragging'), false, 'right browser gesture does not get model drag cursor');
        untouched(h.pointer('pointermove', { pointerType, button: -1, buttons: 2, shiftKey, x: 1150, y: 820 }));
        untouched(h.canvas.dispatch('contextmenu', { button: 2, shiftKey }));
        if (ending !== 'outside-no-canvas-up') untouched(h.pointer(ending, { pointerType, button: 2, buttons: 0, shiftKey, x: 1150, y: 820 }));
        h.tick(3); sameVector(before.position, h.sample().position); sameVector(before.target, h.sample().target);
        assert.equal(h.ctx.picks.length, 0); assert.equal(h.ctx.draws.length, 0); h.assertReleased(); h.assertPaused();
      }
      assert.equal(externalDown, 3, 'unrelated pointer listeners were not blocked');
      h.pointer('pointerdown'); h.pointer('pointerup'); assert.equal(h.ctx.picks.length, 1, 'normal left click still works after right browser gestures');
      h.assertReleased(); h.dispose();
    });
  }
  test(`${renderMode}: releasing Shift midway keeps the whole gesture a smooth pan`, () => {
    const h = setup({ renderMode }), baseline = setup({ renderMode }), before = h.sample();
    for (const g of [h, baseline]) g.pointer('pointerdown', { shiftKey: true });
    for (const [x, y, shiftKey] of [[525, 360, true], [525, 360, false], [555, 375, false], [585, 380, false]]) {
      h.pointer('pointermove', { x, y, button: -1, buttons: 1, shiftKey });
      baseline.pointer('pointermove', { x, y, button: -1, buttons: 1, shiftKey: true });
      h.tick(); baseline.tick();
      sameVector(h.sample().position, baseline.sample().position, 'modifier release causes no position jump');
      sameVector(h.sample().target, baseline.sample().target, 'modifier release keeps the same pan');
    }
    h.pointer('pointerup', { x: 585, y: 380, shiftKey: false }); baseline.pointer('pointerup', { x: 585, y: 380, shiftKey: true });
    assertPan(before, h.sample()); assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.assertPaused(); h.dispose(); baseline.dispose();
  });
  for (const modifier of ['shiftKey', 'ctrlKey', 'metaKey']) test(`${renderMode}: adding ${modifier} midway does not change a started rotation or jump`, () => {
    const h = setup({ renderMode }), baseline = setup({ renderMode }), before = h.sample();
    for (const g of [h, baseline]) g.pointer('pointerdown');
    for (const [x, y, modified] of [[525, 360, false], [525, 360, true], [555, 375, true], [585, 380, false]]) {
      h.pointer('pointermove', { x, y, button: -1, buttons: 1, [modifier]: modified });
      baseline.pointer('pointermove', { x, y, button: -1, buttons: 1 }); h.tick(); baseline.tick();
      sameVector(h.sample().position, baseline.sample().position, 'added modifier causes no position jump');
      sameVector(h.sample().target, before.target, 'started left rotation stays rotation');
    }
    h.pointer('pointerup', { x: 585, y: 380 }); baseline.pointer('pointerup', { x: 585, y: 380 });
    changed(before.direction, h.sample().direction); assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.assertPaused(); h.dispose(); baseline.dispose();
  });
  test(`${renderMode}: Shift-click with Shift released before up never picks`, () => {
    const h = setup({ renderMode }); h.pointer('pointerdown', { shiftKey: true }); h.pointer('pointerup', { shiftKey: false });
    assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.dispose();
  });
  for (const gesture of gestures) for (const stateMode of ['run', 'constraint', 'pose']) test(`${renderMode}: ${gesture.label}, paused ${stateMode}`, () => {
    const h = setup({ renderMode, mode: stateMode }), before = h.sample(); assertDirectBindings(h);
    const { pointerType, button, action, shiftKey = false } = gesture;
    h.pointer('pointerdown', { pointerType, button, shiftKey }); assert(h.canvas.classes.has('dragging')); assert(h.canvas.captures.has(1));
    h.pointer('pointermove', { pointerType, button, shiftKey, x: 570, y: 380 });
    assert.equal(h.ctx.draws.length, 0); assert.equal(h.ctx.dirty, true); h.tick(); assert.equal(h.ctx.draws.length, 1);
    h.pointer('pointerup', { pointerType, button, shiftKey, x: 570, y: 380 });
    if (action === 'pan') assertPan(before, h.sample());
    else { sameVector(before.target, h.sample().target); changed(before.direction, h.sample().direction); near(before.distance, h.sample().distance); }
    assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.assertPaused();
    const draws = h.ctx.draws.length; h.tick(10); assert(h.ctx.draws.length > draws, 'damping continues rendering'); h.tick(500);
    const settled = h.sample(); h.tick(120); sameVector(settled.position, h.sample().position); sameVector(settled.target, h.sample().target); h.assertPaused(); h.dispose();
  });
  test(`${renderMode}: alternate left and Shift+left drags, middle dolly and wheel without toggles`, () => {
    const h = setup({ renderMode });
    for (let i = 0; i < 4; i++) {
      h.ctx.setView('perspective'); assertDirectBindings(h); const initial = h.sample();
      h.drag({ button: 0 }); h.tick(500); sameVector(initial.target, h.sample().target); changed(initial.direction, h.sample().direction);
      const beforePan = h.sample(); h.drag({ shiftKey: true }); h.tick(500); assertPan(beforePan, h.sample());
      const beforeDolly = h.sample(); h.drag({ button: 1, y: 400 }); h.tick(500); assert(h.sample().distance > beforeDolly.distance);
      const beforeWheel = h.sample(), draws = h.ctx.draws.length;
      assert(h.wheel(-120).defaultPrevented); assert(h.sample().distance < beforeWheel.distance); h.tick(); assert.equal(h.ctx.draws.length, draws + 1);
      assert.equal(h.element('#camera-gesture').textContent, desktopHint);
      assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.assertPaused();
    }
    h.dispose();
  });
  for (const expanding of [true, false]) test(`${renderMode}: two-touch ${expanding ? 'spread' : 'pinch'} stays available`, () => {
    const h = setup({ renderMode }), before = h.sample();
    h.pointer('pointerdown', { id: 1, x: 450, pointerType: 'touch' }); h.pointer('pointerdown', { id: 2, x: 550, pointerType: 'touch' });
    h.pointer('pointermove', { id: 1, x: expanding ? 425 : 460, pointerType: 'touch' }); h.pointer('pointermove', { id: 2, x: expanding ? 575 : 540, pointerType: 'touch' });
    assert(expanding ? h.sample().distance < before.distance : h.sample().distance > before.distance); h.tick(); assert.equal(h.ctx.draws.length, 1);
    h.pointer('pointerup', { id: 1, x: 450, pointerType: 'touch' }); h.pointer('pointerup', { id: 2, x: 550, pointerType: 'touch' });
    assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.assertPaused(); h.dispose();
  });
  test(`${renderMode}: two-finger translation pans with no net zoom or rotation`, () => {
    const h = setup({ renderMode }), before = h.sample();
    h.pointer('pointerdown', { id: 1, x: 450, pointerType: 'touch' }); h.pointer('pointerdown', { id: 2, x: 550, pointerType: 'touch' });
    h.pointer('pointermove', { id: 1, x: 490, pointerType: 'touch' }); h.pointer('pointermove', { id: 2, x: 590, pointerType: 'touch' });
    h.pointer('pointerup', { id: 1, x: 490, pointerType: 'touch' }); h.pointer('pointerup', { id: 2, x: 590, pointerType: 'touch' });
    h.tick(500); assertPan(before, h.sample()); assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.assertPaused(); h.dispose();
  });
  for (const shiftKey of [false, true]) for (const view of ['side', 'front', 'perspective']) test(`${renderMode}: ${view} preset clears active ${shiftKey ? 'Shift-pan' : 'left-rotate'} damping`, () => {
    const h = setup({ renderMode }); h.drag({ shiftKey });
    const afterDrag = h.sample(); h.tick(); changed(afterDrag.position, h.sample().position, 'fixture has unconsumed damping');
    h.ctx.setView(view); const preset = h.sample(), expected = { perspective: [2.45, 1.55, 3.15], side: [4.05, 1.07, 0.01], front: [0, 1.07, 4.15] }[view];
    sameVector(preset.position, new THREE.Vector3(...expected), 'preset exact camera'); sameVector(preset.target, new THREE.Vector3(0, 0.89, 0), 'preset recentered');
    assert.equal(h.ctx.orbit.enableDamping, true); h.tick(240); sameVector(preset.position, h.sample().position, 'no post-reset drift'); sameVector(preset.target, h.sample().target);
    for (const viewButton of h.viewButtons) assert.equal(viewButton.attributes['aria-pressed'], String(viewButton.dataset.view === view));
    assertDirectBindings(h); h.wheel(-120); h.tick(); assert(h.sample().distance < preset.distance); h.assertPaused(); h.dispose();
  });
  for (const shiftKey of [false, true]) test(`${renderMode}: repeated ${shiftKey ? 'Shift-pan' : 'left-rotate'} gestures and release outside`, () => {
    const h = setup({ renderMode });
    for (let i = 0; i < 12; i++) {
      const before = h.sample(); h.pointer('pointerdown', { shiftKey }); h.pointer('pointermove', { shiftKey, x: 1100, y: 800 }); h.pointer('pointerup', { shiftKey, x: 1100, y: 800 }); h.tick();
      if (shiftKey) assertPan(before, h.sample());
      assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.assertPaused();
    }
    h.ctx.setView('perspective'); h.pointer('pointerdown'); h.pointer('pointerup'); assert.equal(h.ctx.picks.length, 1, 'left click works after repeated external releases');
    h.assertReleased(); h.dispose();
  });
  for (const shiftKey of [false, true]) test(`${renderMode}: ${shiftKey ? 'Shift-pan' : 'left-rotate'} cancellation clears cursor and repeated gestures recover`, () => {
    const h = setup({ renderMode });
    for (let i = 0; i < 3; i++) {
      h.pointer('pointerdown', { shiftKey }); h.pointer('pointermove', { shiftKey, x: 540 }); h.pointer('pointercancel', { shiftKey, x: 540 });
      assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.pointer('pointerup', { shiftKey }); assert.equal(h.ctx.picks.length, 0);
      h.drag({ shiftKey }); h.assertReleased();
    }
    h.pointer('pointerdown'); h.pointer('pointerup'); assert.equal(h.ctx.picks.length, 1); h.assertReleased(); h.assertPaused(); h.dispose();
  });
  for (const pointerType of ['mouse', 'touch', 'pen']) test(`${renderMode}: genuine ${pointerType} click selects exactly once`, () => {
    const h = setup({ renderMode });
    for (const [x, y] of [[500, 350], [503, 353], [505, 350]]) {
      h.pointer('pointerdown', { pointerType }); h.pointer('pointerup', { pointerType, x, y }); h.assertReleased();
    }
    assert.equal(h.ctx.picks.length, 3); near(h.ctx.picks[0].ndc[0], (500 - 20) / 1000 * 2 - 1); near(h.ctx.picks[0].ndc[1], 1 - (350 - 30) / 700 * 2);
    assert.equal(h.element('#muscle-description').textContent, 'Test muscle'); h.assertPaused(); h.dispose();
  });
  for (const button of [1, 2]) test(`${renderMode}: button ${button} never picks`, () => {
    const h = setup({ renderMode }); h.pointer('pointerdown', { button }); h.pointer('pointerup', { button });
    assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.dispose();
  });
  for (const modifier of ['ctrlKey', 'metaKey', 'shiftKey']) test(`${renderMode}: ${modifier} click never picks`, () => {
    const h = setup({ renderMode }); h.pointer('pointerdown', { [modifier]: true }); h.pointer('pointerup', { [modifier]: true });
    assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.dispose();
  });
  test(`${renderMode}: drag out and back is not mistaken for a click`, () => {
    const h = setup({ renderMode }); h.pointer('pointerdown'); h.pointer('pointermove', { x: 506 }); h.pointer('pointermove'); h.pointer('pointerup');
    assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.dispose();
  });
  test(`${renderMode}: release outside canvas within click tolerance never selects`, () => {
    const h = setup({ renderMode });
    for (const [inside, outside] of [[{ x: 21 }, { x: 19 }], [{ x: 1019 }, { x: 1021 }], [{ y: 31 }, { y: 29 }], [{ y: 729 }, { y: 731 }]]) {
      h.pointer('pointerdown', inside); h.pointer('pointerup', outside); h.assertReleased();
    }
    assert.equal(h.ctx.picks.length, 0); h.dispose();
  });
  for (const shiftKey of [false, true]) test(`${renderMode}: ${shiftKey ? 'Shift-pan' : 'left-rotate'} capture loss terminates cursor/picking before later up`, () => {
    const h = setup({ renderMode }); h.pointer('pointerdown', { shiftKey }); h.canvas.releasePointerCapture(1); h.canvas.dispatch('lostpointercapture', { pointerId: 1 });
    assert.equal(h.canvas.classes.has('dragging'), false); h.pointer('pointerup', { shiftKey }); assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.dispose();
  });
  for (const end of ['pointerup', 'pointercancel']) test(`${renderMode}: replacement finger after ${end} during two-touch gesture never picks`, () => {
    const h = setup({ renderMode });
    h.pointer('pointerdown', { id: 1, pointerType: 'touch' }); h.pointer('pointerdown', { id: 2, x: 550, pointerType: 'touch' }); h.pointer(end, { id: 1, pointerType: 'touch' });
    h.pointer('pointerdown', { id: 3, x: 500, pointerType: 'touch' }); h.pointer('pointerup', { id: 3, x: 500, pointerType: 'touch' });
    assert.equal(h.ctx.picks.length, 0, 'replacement touch is still part of a two-finger gesture');
    h.pointer('pointerup', { id: 2, x: 550, pointerType: 'touch' }); h.assertReleased(); h.dispose();
  });
  test(`${renderMode}: multiple pointers and remaining finger do not pick`, () => {
    const h = setup({ renderMode });
    for (const firstUp of [1, 2]) {
      h.pointer('pointerdown', { id: 1, pointerType: 'touch' }); h.pointer('pointerdown', { id: 2, x: 550, pointerType: 'touch' });
      h.pointer('pointerup', { id: firstUp, x: firstUp === 1 ? 500 : 550, pointerType: 'touch' });
      h.pointer('pointerup', { id: firstUp === 1 ? 2 : 1, x: firstUp === 1 ? 550 : 500, pointerType: 'touch' }); h.assertReleased();
    }
    assert.equal(h.ctx.picks.length, 0); h.pointer('pointerdown'); h.pointer('pointerup'); assert.equal(h.ctx.picks.length, 1); h.dispose();
  });
}
const failed = results.filter(result => result.status === 'failed').length;
console.log(`${failed ? 'FAIL' : 'PASS'} ${results.length - failed}/${results.length} direct camera gesture/picking cases (real Three.js ${THREE.REVISION} controls).`);
console.log('Production control/view/hint/render-loop functions + imported picking; synthetic DOM/input/rAF; Canvas/WebGL render dispatch only.');
fs.writeFileSync(new URL('QA-camera-pan.json', root), JSON.stringify({ status: failed ? 'failed' : 'passed', passed: results.length - failed, failed, cases: results.length, threeRevision: THREE.REVISION, scope: 'Real Three.js OrbitControls with extracted production direct camera/view/hint/loop and imported bindCanvasPicking. Direct left rotate/Shift+left pan/wheel zoom, browser-owned right button and touch gestures, no camera-mode toggles. DOM/input/rAF stubs, no browser layout or actual renderer pixels.', results }, null, 2) + '\n');
if (failed) process.exitCode = 1;
