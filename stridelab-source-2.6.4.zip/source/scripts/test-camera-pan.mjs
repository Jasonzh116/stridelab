// Real Three.js OrbitControls + production direct camera/view/hint/loop functions and
// imported production canvas picking. Synthetic DOM/input/rAF; render dispatch is
// stubbed. This does not claim browser pointer routing or physical-device coverage.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { bindCanvasPicking } from '../src/camera-input.js';
const root = new URL('../', import.meta.url);
const source = fs.readFileSync(new URL('src/app.js', root), 'utf8');
function extract(pattern, name) {
  const result = source.match(pattern)?.[0];
  assert(result, `Could not extract production ${name}; update harness if structure changed`);
  return result;
}
const stateSource = extract(/^const state=.*;$/m, 'state');
const cameraSource = extract(/camera=new THREE\.PerspectiveCamera\([^;]+\);/, 'camera');
const targetSource = extract(/target=new THREE\.Vector3\([^;]+\);/, 'target');
const setupSource = extract(/orbit=new OrbitControls\(camera,canvas\);[\s\S]*?setView\('perspective'\);/, 'controls setup');
const hintSource = source.slice(source.indexOf('let cameraInput='), source.indexOf('\nfunction setView('));
const viewSource = extract(/^function setView\(name\).*$/m, 'setView');
const loopSource = extract(/^function loop\(now\).*$/m, 'loop');
const pickingSource = extract(/bindCanvasPicking\(canvas,e=>\{.*?model\.hit\(p,camera\);select\(h\?\.id\?\?null\);\}\);/, 'initialization of guarded picking');

class EventSurface {
  constructor() {
    this.listeners = new Map(); this.style = {}; this.dataset = {}; this.attributes = {};
    this.clientWidth = 1000; this.clientHeight = 700; this.captures = new Set(); this.classes = new Set();
    this.classList = {
      add: name => this.classes.add(name), remove: name => this.classes.delete(name), contains: name => this.classes.has(name),
      toggle: (name, on = !this.classes.has(name)) => on ? this.classes.add(name) : this.classes.delete(name),
    };
  }
  addEventListener(type, listener, options = {}) {
    const entries = this.listeners.get(type) || [];
    if (!entries.some(entry => entry.listener === listener)) entries.push({ listener, options });
    this.listeners.set(type, entries);
  }
  removeEventListener(type, listener) { this.listeners.set(type, (this.listeners.get(type) || []).filter(entry => entry.listener !== listener)); }
  dispatch(type, values = {}) {
    const event = { type, target: this, defaultPrevented: false, ...values };
    let options = {};
    event.preventDefault = () => { if (!options.passive) event.defaultPrevented = true; };
    for (const entry of [...(this.listeners.get(type) || [])]) { options = entry.options; entry.listener(event); }
    return event;
  }
  getRootNode() { return this.root || this; }
  getBoundingClientRect() { return { left: 20, top: 30, right: 1020, bottom: 730, width: this.clientWidth, height: this.clientHeight }; }
  setPointerCapture(id) { this.captures.add(id); }
  releasePointerCapture(id) { this.captures.delete(id); }
  setAttribute(name, value) { this.attributes[name] = value; }
}
function setup({ renderMode = 'canvas', mode = 'run', wrongRightButton = false } = {}) {
  const canvas = new EventSurface(), document = new EventSurface(), elements = new Map(); canvas.root = document; document.hidden = false;
  const element = selector => { if (!elements.has(selector)) elements.set(selector, new EventSurface()); return elements.get(selector); };
  const viewButtons = ['perspective', 'side', 'front'].map(view => { const b = new EventSurface(); b.dataset.view = view; return b; });
  const ctx = {
    THREE, OrbitControls, bindCanvasPicking, canvas, document, scene: new THREE.Scene(), dirty: true, lastTime: 0, lastDraw: 0, uiElapsed: 0,
    poses: 0, overlays: 0, draws: [], picks: [], model: { runningResult: { cycleSeconds: 0.78 }, select: id => id ? { name: id, label: id } : null },
    matchMedia: () => ({ matches: false }), $: element,
    $$: selector => selector === '[data-view]' ? viewButtons : [],
    text: (s, value) => { element(s).textContent = value; },
    pose() { ctx.poses++; ctx.dirty = true; }, updateUI() {}, drawConstraintOverlay() { ctx.overlays++; }, requestAnimationFrame() {},
  };
  vm.createContext(ctx);
  vm.runInContext(`${stateSource}\nthis.state=state;\n${cameraSource}\n${targetSource}\n${hintSource}\n${viewSource}\n${setupSource}\n${loopSource}`, ctx);
  if (wrongRightButton) ctx.orbit.mouseButtons.RIGHT = THREE.MOUSE.ROTATE;
  ctx.state.ready = true; ctx.state.renderMode = renderMode; ctx.state.mode = mode; ctx.state.playing = false; ctx.state.phase = 0.37;
  ctx.model.hit = (point, camera) => { assert.equal(camera, ctx.camera); ctx.picks.push({ ndc: point.toArray() }); return { id: 'Test muscle' }; };
  vm.runInContext(pickingSource, ctx);
  const baselineMove = canvas.listeners.get('pointermove').length, baselineUp = canvas.listeners.get('pointerup').length;
  const sample = () => ({ position: ctx.camera.position.clone(), target: ctx.orbit.target.clone(), direction: ctx.camera.position.clone().sub(ctx.orbit.target), quaternion: ctx.camera.quaternion.clone(), distance: ctx.camera.position.distanceTo(ctx.orbit.target) });
  ctx.renderer = { render(...args) { assert.equal(args.length, renderMode === 'webgl' ? 2 : 0); ctx.draws.push(sample()); } };
  let now = 0;
  const tick = (count = 1) => { for (let i = 0; i < count; i++) ctx.loop(now += 1000 / 60); };
  const pointer = (type, { id = 1, x = 500, y = 350, pointerType = 'mouse', button = 0, ...extra } = {}) => {
    const held = canvas.captures.has(id);
    const event = canvas.dispatch(type, { pointerId: id, pointerType, pageX: x, pageY: y, clientX: x, clientY: y, button, ...extra });
    // Pointerup/cancel implicit release and lostcapture follow input dispatch.
    // Touch implicit capture is not emulated; browser routing is a separate QA layer.
    if (type === 'pointerup' || type === 'pointercancel') {
      canvas.releasePointerCapture(id);
      if (held) canvas.dispatch('lostpointercapture', { pointerId: id, pointerType });
    }
    return event;
  };
  const wheel = (deltaY, extra = {}) => canvas.dispatch('wheel', { deltaY, deltaMode: 0, ctrlKey: false, clientX: 500, clientY: 350, ...extra });
  const drag = ({ pointerType = 'mouse', button = 0, x = 570, y = 380, ...extra } = {}) => {
    pointer('pointerdown', { pointerType, button, ...extra }); pointer('pointermove', { pointerType, button, x, y, ...extra }); pointer('pointerup', { pointerType, button, x, y, ...extra });
  };
  const assertPaused = () => { assert.equal(ctx.state.phase, 0.37, 'camera must preserve paused gait phase'); assert.equal(ctx.state.playing, false); assert.equal(ctx.poses, 0); };
  const assertReleased = () => {
    assert.equal(canvas.captures.size, 0, 'pointer capture released'); assert.equal(canvas.classes.has('dragging'), false, 'drag cursor terminated');
    assert.equal(canvas.listeners.get('pointermove').length, baselineMove, 'temporary controls move listener removed');
    assert.equal(canvas.listeners.get('pointerup').length, baselineUp, 'temporary controls up listener removed');
  };
  tick(); ctx.draws.length = 0; ctx.overlays = 0;
  return { ctx, canvas, element, viewButtons, pointer, wheel, drag, tick, sample, assertPaused, assertReleased, dispose: () => ctx.orbit.dispose() };
}
const results = [];
function test(name, run) {
  try { run(); results.push({ name, status: 'passed' }); }
  catch (error) { results.push({ name, status: 'failed', error: error.message }); console.error(`FAIL ${name}\n${error.stack}`); }
}
const near = (a, b, message = 'values match') => assert(Math.abs(a - b) < 1e-9, `${message}: ${a} vs ${b}`);
const sameVector = (a, b, message = 'vectors match') => assert(a.distanceTo(b) < 1e-9, `${message}: ${a.toArray()} vs ${b.toArray()}`);
function changed(a, b, message = 'vectors differ') { assert(a.distanceTo(b) > 1e-5, message); }
function assertPan(before, after) {
  changed(before.target, after.target, 'pan translates target');
  sameVector(after.position.clone().sub(before.position), after.target.clone().sub(before.target), 'pan translates camera and target equally');
  sameVector(before.direction, after.direction, 'pan preserves viewing direction'); near(before.distance, after.distance, 'pan preserves zoom');
}
const desktopHint = '左键拖动旋转 · 右键拖动平移 · 滚轮缩放';
function assertDirectBindings(h) {
  assert.deepEqual({ ...h.ctx.orbit.mouseButtons }, { LEFT: THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN });
  assert.deepEqual({ ...h.ctx.orbit.touches }, { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN });
  const viewport = h.element('#viewport');
  assert.equal(Object.hasOwn(viewport.attributes, 'aria-pressed'), false);
  assert.equal(viewport.classes.has('active'), false);
  assert.equal(viewport.onclick == null, true);
  assert.equal(Object.hasOwn(viewport.dataset, 'cameraMode'), false);
}
const gestures = [
  { label: 'left mouse rotation', pointerType: 'mouse', button: 0, action: 'rotate' },
  { label: 'right mouse pan', pointerType: 'mouse', button: 2, action: 'pan' },
  { label: 'one-finger rotation', pointerType: 'touch', button: 0, action: 'rotate' },
];
for (const renderMode of ['canvas', 'webgl']) {
  test(`${renderMode}: direct gestures need no mode state or buttons`, () => {
    const h = setup({ renderMode }); assertDirectBindings(h);
    assert(!source.includes('setCameraMode') && !source.includes('data-camera-mode') && !source.includes('cameraMode'));
    h.dispose();
  });
  test(`${renderMode}: negative control detects RIGHT remapped to ROTATE`, () => {
    const h = setup({ renderMode, wrongRightButton: true }), before = h.sample(); h.drag({ button: 2 });
    assert.throws(() => assertPan(before, h.sample()), /pan translates target/); h.dispose();
  });
  test(`${renderMode}: context menu suppressed on canvas only`, () => {
    const h = setup({ renderMode });
    assert(h.canvas.dispatch('contextmenu').defaultPrevented, 'OrbitControls suppresses canvas context menu');
    assert.equal(h.ctx.document.dispatch('contextmenu').defaultPrevented, false, 'document retains normal context menu');
    assert.equal(h.element('#viewport').dispatch('contextmenu').defaultPrevented, false, 'non-canvas viewport retains normal context menu');
    assert.equal(new EventSurface().dispatch('contextmenu').defaultPrevented, false, 'unrelated content retains normal context menu');
    assert.equal(h.canvas.listeners.get('contextmenu').length, 1, 'only OrbitControls context menu handler');
    assert(!/(?:document|window)\s*\.\s*(?:addEventListener\(['"]contextmenu|oncontextmenu)/.test(source), 'no global context menu suppression');
    h.dispose();
  });
  for (const gesture of gestures) for (const stateMode of ['run', 'constraint', 'pose']) test(`${renderMode}: ${gesture.label}, paused ${stateMode}`, () => {
    const h = setup({ renderMode, mode: stateMode }), before = h.sample(); assertDirectBindings(h);
    const { pointerType, button, action } = gesture;
    h.pointer('pointerdown', { pointerType, button }); assert(h.canvas.classes.has('dragging')); assert(h.canvas.captures.has(1));
    h.pointer('pointermove', { pointerType, button, x: 570, y: 380 });
    assert.equal(h.ctx.draws.length, 0); assert.equal(h.ctx.dirty, true); h.tick(); assert.equal(h.ctx.draws.length, 1);
    h.pointer('pointerup', { pointerType, button, x: 570, y: 380 });
    if (action === 'pan') assertPan(before, h.sample());
    else { sameVector(before.target, h.sample().target); changed(before.direction, h.sample().direction); near(before.distance, h.sample().distance); }
    assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.assertPaused();
    const draws = h.ctx.draws.length; h.tick(10); assert(h.ctx.draws.length > draws, 'damping continues rendering'); h.tick(500);
    const settled = h.sample(); h.tick(120); sameVector(settled.position, h.sample().position); sameVector(settled.target, h.sample().target); h.assertPaused(); h.dispose();
  });
  test(`${renderMode}: alternate direct left/right drags, middle dolly and wheel without toggles`, () => {
    const h = setup({ renderMode });
    for (let i = 0; i < 4; i++) {
      h.ctx.setView('perspective'); assertDirectBindings(h); const initial = h.sample();
      h.drag({ button: 0 }); h.tick(500); sameVector(initial.target, h.sample().target); changed(initial.direction, h.sample().direction);
      const beforePan = h.sample(); h.drag({ button: 2 }); h.tick(500); assertPan(beforePan, h.sample());
      const beforeDolly = h.sample(); h.drag({ button: 1, y: 400 }); h.tick(500); assert(h.sample().distance > beforeDolly.distance);
      const beforeWheel = h.sample(), draws = h.ctx.draws.length;
      assert(h.wheel(-120).defaultPrevented); assert(h.sample().distance < beforeWheel.distance); h.tick(); assert.equal(h.ctx.draws.length, draws + 1);
      assert.equal(h.element('#camera-gesture').textContent, desktopHint);
      assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.assertPaused();
    }
    h.dispose();
  });
  for (const expanding of [true, false]) test(`${renderMode}: two-touch ${expanding ? 'spread' : 'pinch'} stays available`, () => {
    const h = setup({ renderMode }), before = h.sample();
    h.pointer('pointerdown', { id: 1, x: 450, pointerType: 'touch' }); h.pointer('pointerdown', { id: 2, x: 550, pointerType: 'touch' });
    h.pointer('pointermove', { id: 1, x: expanding ? 425 : 460, pointerType: 'touch' }); h.pointer('pointermove', { id: 2, x: expanding ? 575 : 540, pointerType: 'touch' });
    assert(expanding ? h.sample().distance < before.distance : h.sample().distance > before.distance); h.tick(); assert.equal(h.ctx.draws.length, 1);
    h.pointer('pointerup', { id: 1, x: 450, pointerType: 'touch' }); h.pointer('pointerup', { id: 2, x: 550, pointerType: 'touch' });
    assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.assertPaused(); h.dispose();
  });
  test(`${renderMode}: two-finger translation pans with no net zoom or rotation`, () => {
    const h = setup({ renderMode }), before = h.sample();
    h.pointer('pointerdown', { id: 1, x: 450, pointerType: 'touch' }); h.pointer('pointerdown', { id: 2, x: 550, pointerType: 'touch' });
    h.pointer('pointermove', { id: 1, x: 490, pointerType: 'touch' }); h.pointer('pointermove', { id: 2, x: 590, pointerType: 'touch' });
    h.pointer('pointerup', { id: 1, x: 490, pointerType: 'touch' }); h.pointer('pointerup', { id: 2, x: 590, pointerType: 'touch' });
    h.tick(500); assertPan(before, h.sample()); assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.assertPaused(); h.dispose();
  });
  for (const button of [0, 2]) for (const view of ['side', 'front', 'perspective']) test(`${renderMode}: ${view} preset clears active ${button === 2 ? 'right-pan' : 'left-rotate'} damping`, () => {
    const h = setup({ renderMode }); h.drag({ button });
    const afterDrag = h.sample(); h.tick(); changed(afterDrag.position, h.sample().position, 'fixture has unconsumed damping');
    h.ctx.setView(view); const preset = h.sample(), expected = { perspective: [2.45, 1.55, 3.15], side: [4.05, 1.07, 0.01], front: [0, 1.07, 4.15] }[view];
    sameVector(preset.position, new THREE.Vector3(...expected), 'preset exact camera'); sameVector(preset.target, new THREE.Vector3(0, 0.89, 0), 'preset recentered');
    assert.equal(h.ctx.orbit.enableDamping, true); h.tick(240); sameVector(preset.position, h.sample().position, 'no post-reset drift'); sameVector(preset.target, h.sample().target);
    for (const viewButton of h.viewButtons) assert.equal(viewButton.attributes['aria-pressed'], String(viewButton.dataset.view === view));
    assertDirectBindings(h); h.wheel(-120); h.tick(); assert(h.sample().distance < preset.distance); h.assertPaused(); h.dispose();
  });
  for (const button of [0, 2]) test(`${renderMode}: repeated button-${button} gestures and release outside`, () => {
    const h = setup({ renderMode });
    for (let i = 0; i < 12; i++) {
      const before = h.sample(); h.pointer('pointerdown', { button }); h.pointer('pointermove', { button, x: 1100, y: 800 }); h.pointer('pointerup', { button, x: 1100, y: 800 }); h.tick();
      if (button === 2) assertPan(before, h.sample());
      assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.assertPaused();
    }
    h.ctx.setView('perspective'); h.pointer('pointerdown'); h.pointer('pointerup'); assert.equal(h.ctx.picks.length, 1, 'left click works after repeated external releases');
    h.assertReleased(); h.dispose();
  });
  for (const button of [0, 2]) test(`${renderMode}: button-${button} cancellation clears cursor and repeated gestures recover`, () => {
    const h = setup({ renderMode });
    for (let i = 0; i < 3; i++) {
      h.pointer('pointerdown', { button }); h.pointer('pointermove', { button, x: 540 }); h.pointer('pointercancel', { button, x: 540 });
      assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.pointer('pointerup', { button }); assert.equal(h.ctx.picks.length, 0);
      h.drag({ button }); h.assertReleased();
    }
    h.pointer('pointerdown'); h.pointer('pointerup'); assert.equal(h.ctx.picks.length, 1); h.assertReleased(); h.assertPaused(); h.dispose();
  });
  for (const pointerType of ['mouse', 'touch', 'pen']) test(`${renderMode}: genuine ${pointerType} click selects exactly once`, () => {
    const h = setup({ renderMode });
    for (const [x, y] of [[500, 350], [503, 353], [505, 350]]) {
      h.pointer('pointerdown', { pointerType }); h.pointer('pointerup', { pointerType, x, y }); h.assertReleased();
    }
    assert.equal(h.ctx.picks.length, 3); near(h.ctx.picks[0].ndc[0], (500 - 20) / 1000 * 2 - 1); near(h.ctx.picks[0].ndc[1], 1 - (350 - 30) / 700 * 2);
    assert.equal(h.element('#muscle-description').textContent, 'Test muscle'); h.assertPaused(); h.dispose();
  });
  for (const button of [1, 2]) test(`${renderMode}: button ${button} never picks`, () => {
    const h = setup({ renderMode }); h.pointer('pointerdown', { button }); h.pointer('pointerup', { button });
    assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.dispose();
  });
  for (const modifier of ['ctrlKey', 'metaKey', 'shiftKey']) test(`${renderMode}: ${modifier} click never picks`, () => {
    const h = setup({ renderMode }); h.pointer('pointerdown', { [modifier]: true }); h.pointer('pointerup', { [modifier]: true });
    assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.dispose();
  });
  test(`${renderMode}: drag out and back is not mistaken for a click`, () => {
    const h = setup({ renderMode }); h.pointer('pointerdown'); h.pointer('pointermove', { x: 506 }); h.pointer('pointermove'); h.pointer('pointerup');
    assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.dispose();
  });
  test(`${renderMode}: release outside canvas within click tolerance never selects`, () => {
    const h = setup({ renderMode });
    for (const [inside, outside] of [[{ x: 21 }, { x: 19 }], [{ x: 1019 }, { x: 1021 }], [{ y: 31 }, { y: 29 }], [{ y: 729 }, { y: 731 }]]) {
      h.pointer('pointerdown', inside); h.pointer('pointerup', outside); h.assertReleased();
    }
    assert.equal(h.ctx.picks.length, 0); h.dispose();
  });
  for (const button of [0, 2]) test(`${renderMode}: button-${button} capture loss terminates cursor/picking before later up`, () => {
    const h = setup({ renderMode }); h.pointer('pointerdown', { button }); h.canvas.releasePointerCapture(1); h.canvas.dispatch('lostpointercapture', { pointerId: 1 });
    assert.equal(h.canvas.classes.has('dragging'), false); h.pointer('pointerup', { button }); assert.equal(h.ctx.picks.length, 0); h.assertReleased(); h.dispose();
  });
  for (const end of ['pointerup', 'pointercancel']) test(`${renderMode}: replacement finger after ${end} during two-touch gesture never picks`, () => {
    const h = setup({ renderMode });
    h.pointer('pointerdown', { id: 1, pointerType: 'touch' }); h.pointer('pointerdown', { id: 2, x: 550, pointerType: 'touch' }); h.pointer(end, { id: 1, pointerType: 'touch' });
    h.pointer('pointerdown', { id: 3, x: 500, pointerType: 'touch' }); h.pointer('pointerup', { id: 3, x: 500, pointerType: 'touch' });
    assert.equal(h.ctx.picks.length, 0, 'replacement touch is still part of a two-finger gesture');
    h.pointer('pointerup', { id: 2, x: 550, pointerType: 'touch' }); h.assertReleased(); h.dispose();
  });
  test(`${renderMode}: multiple pointers and remaining finger do not pick`, () => {
    const h = setup({ renderMode });
    for (const firstUp of [1, 2]) {
      h.pointer('pointerdown', { id: 1, pointerType: 'touch' }); h.pointer('pointerdown', { id: 2, x: 550, pointerType: 'touch' });
      h.pointer('pointerup', { id: firstUp, x: firstUp === 1 ? 500 : 550, pointerType: 'touch' });
      h.pointer('pointerup', { id: firstUp === 1 ? 2 : 1, x: firstUp === 1 ? 550 : 500, pointerType: 'touch' }); h.assertReleased();
    }
    assert.equal(h.ctx.picks.length, 0); h.pointer('pointerdown'); h.pointer('pointerup'); assert.equal(h.ctx.picks.length, 1); h.dispose();
  });
}
const failed = results.filter(result => result.status === 'failed').length;
console.log(`${failed ? 'FAIL' : 'PASS'} ${results.length - failed}/${results.length} direct camera gesture/picking cases (real Three.js ${THREE.REVISION} controls).`);
console.log('Production control/view/hint/render-loop functions + imported picking; synthetic DOM/input/rAF; Canvas/WebGL render dispatch only.');
fs.writeFileSync(new URL('QA-camera-pan.json', root), JSON.stringify({ status: failed ? 'failed' : 'passed', passed: results.length - failed, failed, cases: results.length, threeRevision: THREE.REVISION, scope: 'Real Three.js OrbitControls with extracted production direct camera/view/hint/loop and imported bindCanvasPicking. Direct left rotate/right pan/wheel zoom and touch gestures, no camera-mode toggles. DOM/input/rAF stubs, no browser layout or actual renderer pixels.', results }, null, 2) + '\n');
if (failed) process.exitCode = 1;
