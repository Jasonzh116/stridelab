"""Derive RBDS003 speed-specific timing from authorized public force data.
Dependencies: numpy, scipy. Does not modify the viewer app.
Run from any directory; inputs live in the adjacent raw directory.
"""
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy.signal import butter, sosfiltfilt

ROOT = Path(__file__).parent
SOURCES = json.loads((ROOT / 'raw-force-sources-RBDS003.json').read_text())
FS = 300.0
CUTOFF_HZ = 10.0
THRESHOLD_N = 20.0

processed = (ROOT / 'RBDS003processed.txt').read_text().splitlines()
columns = processed[0].split()
data = np.array([[float(v) for v in line.split()] for line in processed[1:]])
results = []
for token in ['25', '35', '45']:
    name = f'RBDS003runT{token}forces.txt'
    source = next(f for f in SOURCES if f['name'] == name)
    path = ROOT / 'raw' / name
    actual_md5 = hashlib.md5(path.read_bytes()).hexdigest()
    if actual_md5 != source['computed_md5']:
        raise ValueError(f'MD5 mismatch: {name}')
    raw = np.loadtxt(path, skiprows=1)
    # The first column is sample number, not seconds; source kinetics are 300 Hz.
    force = sosfiltfilt(butter(4, CUTOFF_HZ, fs=FS, output='sos'), raw[:, 2])
    contact = force > THRESHOLD_N
    candidates = np.flatnonzero(np.diff(contact.astype(int)) == 1) + 1
    ends = np.flatnonzero(np.diff(contact.astype(int)) == -1) + 1
    # Zero-phase filtering yields tiny isolated ringing pulses in flight.
    # Retain 20 N event times only for pulses reaching at least 100 N.
    # Real contacts here exceed 1000 N; discarded pulses stay below 40 N.
    accepted = []
    rejected_peaks = []
    for start in candidates:
        next_ends = ends[ends > start]
        end = next_ends[0] if len(next_ends) else len(force)
        peak = force[start:end].max()
        if peak >= 100:
            accepted.append(start)
        else:
            rejected_peaks.append(float(peak))
    starts = np.array(accepted, dtype=int)
    # Subjects ran with both feet on one instrumented treadmill belt.
    # Consecutive force contacts are steps; every second contact spans a stride.
    step_s = np.diff(starts) / FS
    stride_s = (starts[2:] - starts[:-2]) / FS
    complete = [(start, ends[ends > start][0]) for start in starts if np.any(ends > start)]
    stance_s = np.array([(end - start) / FS for start, end in complete])
    step_cycle_contacts = []
    for i, start in enumerate(starts[:-2]):
        future_ends = ends[ends > start]
        if len(future_ends):
            step_cycle_contacts.append((future_ends[0] - start) / (starts[i + 2] - start))
    endpoints = {}
    for side in ['R', 'L']:
        values = data[:, columns.index(f'{side}grfY{token}')]
        last = np.flatnonzero(np.isfinite(values))[-1]
        endpoints[side] = {
            'column': f'{side}grfY{token}',
            'last_finite_phase_percent': float(data[last, 0]),
            'first_missing_phase_percent': float(data[last + 1, 0]),
            'last_finite_force_N_per_kg': float(values[last]),
        }
    item = {
        'speed_m_per_s': int(token) / 10,
        'strike_right': 'Rearfoot',
        'strike_left': 'Rearfoot',
        'raw_file': name,
        'raw_url': source['download_url'],
        'raw_figshare_file_id': source['id'],
        'raw_md5': actual_md5,
        'raw_sample_count': int(len(raw)),
        'raw_sample_rate_hz': FS,
        'raw_duration_s': len(raw) / FS,
        'touchdown_count': int(len(starts)),
        'candidate_touchdown_count': int(len(candidates)),
        'excluded_low_amplitude_ringing_pulses': len(rejected_peaks),
        'max_excluded_pulse_peak_N': max(rejected_peaks) if rejected_peaks else None,
        'step_interval_count': int(len(step_s)),
        'stride_interval_count': int(len(stride_s)),
        'mean_step_duration_s': float(np.mean(step_s)),
        'mean_stride_duration_s': float(np.mean(stride_s)),
        'stride_frequency_hz': float(1 / np.mean(stride_s)),
        'cadence_steps_per_min': float(60 / np.mean(step_s)),
        'stride_length_m_derived_from_treadmill_speed': float((int(token) / 10) * np.mean(stride_s)),
        'step_length_m_derived_from_treadmill_speed': float((int(token) / 10) * np.mean(step_s)),
        'min_step_duration_s': float(np.min(step_s)),
        'max_step_duration_s': float(np.max(step_s)),
        'mean_stance_duration_s': float(np.mean(stance_s)),
        'mean_stance_fraction_from_raw_contacts': float(np.mean(step_cycle_contacts)),
        'processed_grf_stance_endpoints': endpoints,
    }
    results.append(item)

out = {
    'participant': 'RBDS003',
    'dataset_doi': '10.6084/m9.figshare.4543435.v5',
    'dataset_url': 'https://doi.org/10.6084/m9.figshare.4543435.v5',
    'paper_doi': '10.7717/peerj.3298',
    'license': 'CC BY 4.0',
    'license_url': 'https://creativecommons.org/licenses/by/4.0/',
    'source_metadata_url': 'https://api.figshare.com/v2/articles/4543435',
    'footstrike_source_url': 'https://ndownloader.figshare.com/files/39452932',
    'footstrike_source_columns': ['RFSI25', 'LFSI25', 'RFSI35', 'LFSI35', 'RFSI45', 'LFSI45'],
    'vertical_force': {'raw_column': 'Fy', 'direction': 'positive upward', 'raw_units': 'N', 'processed_columns': 'RgrfYxx/LgrfYxx', 'processed_units': 'N/kg'},
    'method': {
        'status': 'computed from the raw trials; not published per-subject timing fields',
        'filter': 'scipy.signal.butter(4, 10, fs=300, output=sos), applied forward/backward with sosfiltfilt',
        'threshold_N': THRESHOLD_N,
        'contact_pulse_validation': 'Retain pulses reaching >=100 N to reject isolated post-filter flight ringing (all excluded peaks below 40 N, true force peaks above 1000 N). Touchdown/toe-off times still use the 20 N threshold; this validation is an analysis addition, not claimed to be the exact published pipeline.',
        'events': 'First sampled frame above 20 N after a below-threshold frame is touchdown; reverse is toe-off. Initial/final incomplete intervals excluded.',
        'cadence': '60 / mean successive-touchdown interval in seconds; each contact is one step',
        'stride': 'mean time between every second touchdown; complete intervals only',
        'stance': 'mean touchdown-to-next-toe-off duration',
        'stride_length': 'treadmill belt speed times mean stride duration; equivalent forward travel per stride, not measured progression in the stationary lab coordinate frame',
        'validation': '100, 300, and 500 N minimum-pulse-peak validation produced identical accepted touchdown counts at each speed.',
        'stance_fraction': 'mean touchdown-to-toe-off duration divided by the corresponding every-second-touchdown interval',
        'sampling_resolution_s': 1 / FS,
        'processed_stance_boundary_warning': 'The mean curves become NaN after stance. Their finite/missing boundary is a 1%-grid approximation, not an exact raw 20 N crossing.',
    },
    'results': results,
    'verified_date': '2026-10-01',
}
(ROOT / 'timing-RBDS003-all-speeds.json').write_text(json.dumps(out, indent=2) + '\n')
for r in results:
    print(r['speed_m_per_s'], round(r['cadence_steps_per_min'], 3), round(r['mean_stride_duration_s'], 6), round(r['mean_stance_duration_s'], 6), round(r['mean_stance_fraction_from_raw_contacts'], 6))
