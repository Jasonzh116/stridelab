// Source-derived joint axes; authored closed-fist hand pose, not captured running data.
// Call only in running mode after the base rig resets its joints.
import * as THREE from 'three';
export function createHandRelaxation(byName,handRig){
 const descriptors=(handRig?.digits||[]).map(d=>({...d,bone:byName[d.name],flexAxis:new THREE.Vector3(...d.flexAxis),splayAxis:new THREE.Vector3(...d.splayAxis)}));
 const q=new THREE.Quaternion(),D=Math.PI/180;for(const d of descriptors){d.closed=new THREE.Quaternion().setFromAxisAngle(d.flexAxis,d.flexDegrees*D).premultiply(q.setFromAxisAngle(d.splayAxis,d.splayDegrees*D));}
 return function applyHandRelaxation(strength=1){
  const weight=Math.max(0,Math.min(1,strength));
  for(const d of descriptors){if(!d.bone)continue;if(weight===1){d.bone.quaternion.copy(d.closed);continue;}d.bone.quaternion.setFromAxisAngle(d.flexAxis,d.flexDegrees*weight*D);d.bone.quaternion.premultiply(q.setFromAxisAngle(d.splayAxis,d.splayDegrees*weight*D));}
 };
}
