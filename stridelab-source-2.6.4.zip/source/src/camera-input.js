// Three r180 captures pointers before checking mouseButtons, and always cancels
// contextmenu. Leave right-button browser/extension gestures completely alone.
// Keep this small adapter covered by the real OrbitControls integration tests
// when upgrading the pinned Three.js version.
export function configureBrowserSafeCamera(orbit, canvas) {
  const pointerDown = orbit._onPointerDown;
  canvas.removeEventListener('pointerdown', pointerDown);
  orbit._onPointerDown = event => {
    if (event.pointerType !== 'touch' && event.button === 2) return;
    pointerDown(event);
  };
  canvas.addEventListener('pointerdown', orbit._onPointerDown);
  canvas.removeEventListener('contextmenu', orbit._onContextMenu);
}

// OrbitControls owns camera gestures and pointer capture. This only distinguishes
// a genuine click from a drag, cancellation, or multi-pointer gesture for picking.
export function bindCanvasPicking(canvas, onPick) {
  const pointers = new Set();
  let press = null;
  const cancel = event => {
    press = null;
    pointers.delete(event.pointerId);
    if (!pointers.size) canvas.classList.remove('dragging');
  };
  canvas.addEventListener('pointerdown', event => {
    if (event.pointerType !== 'touch' && event.button === 2) return;
    pointers.add(event.pointerId);
    canvas.classList.add('dragging');
    press = pointers.size === 1 && event.button === 0
      && !event.ctrlKey && !event.metaKey && !event.shiftKey
      ? { id: event.pointerId, x: event.clientX, y: event.clientY, moved: false }
      : null;
  });
  canvas.addEventListener('pointermove', event => {
    if (press?.id === event.pointerId && Math.hypot(event.clientX - press.x, event.clientY - press.y) > 5) press.moved = true;
  });
  canvas.addEventListener('pointerup', event => {
    const click = press;
    press = null;
    pointers.delete(event.pointerId);
    if (!pointers.size) canvas.classList.remove('dragging');
    if (!click || click.id !== event.pointerId || click.moved || event.button !== 0
      || Math.hypot(event.clientX - click.x, event.clientY - click.y) > 5) return;
    const rect = canvas.getBoundingClientRect();
    // Captured pointerup can arrive outside the canvas; never pick there.
    if (event.clientX < rect.left || event.clientX > rect.right
      || event.clientY < rect.top || event.clientY > rect.bottom) return;
    onPick(event);
  });
  canvas.addEventListener('pointercancel', cancel);
  canvas.addEventListener('lostpointercapture', cancel);
}
