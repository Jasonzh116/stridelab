StrideLab logo B: 双相回环
Selected 2026-10-03. Original vector files retained here.
The exact mark.svg artwork is inline in index.template.html; favicon.svg is embedded as a data URI.
Only header branding and the browser favicon changed. Application code and model assets are unchanged.
