import {build} from 'esbuild';import fs from 'node:fs';
await fs.promises.mkdir('dist',{recursive:true});
const r=await build({entryPoints:['src/app.js'],bundle:true,minify:true,format:'iife',target:'es2020',write:false,legalComments:'inline'});
const html=fs.readFileSync('index.template.html','utf8').replace('/*CSS*/',fs.readFileSync('style.css','utf8')).replace('/*JS*/',()=>r.outputFiles[0].text.replace(/<\/script/gi,'<\\/script'));
const notices='<!-- Third-party library notices\n'+fs.readFileSync('node_modules/three/LICENSE','utf8')+'\n'+fs.readFileSync('node_modules/fflate/LICENSE','utf8')+'\n-->\n';
fs.writeFileSync('dist/index.html',html.replace('</head>',notices+'</head>'));fs.copyFileSync('node_modules/three/LICENSE','dist/THREE-LICENSE.txt');
fs.copyFileSync('licenses/ANATOMY-ATTRIBUTION.txt','dist/ANATOMY-ATTRIBUTION.txt');
fs.copyFileSync('licenses/Z-ANATOMY-ATTRIBUTION.txt','dist/Z-ANATOMY-ATTRIBUTION.txt');
fs.copyFileSync('licenses/FFLATE-LICENSE.txt','dist/FFLATE-LICENSE.txt');
console.log(`Built offline-ready HTML: ${(html.length/1024).toFixed(0)} KiB`);

fs.copyFileSync('licenses/MOTION-ATTRIBUTION.txt','dist/MOTION-ATTRIBUTION.txt');fs.copyFileSync('motion-reference/LICENSE-CC-BY-4.0.txt','dist/MOTION-CC-BY-4.0.txt');
