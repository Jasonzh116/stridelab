# 2.6.4：背部组织附着修正（当前版本）

源图谱中“Interspinous ligaments”（棘间韧带）的背部薄片放在骨骼显示层；它不是已确认的后纵韧带。旧绑定把从骶部延伸到颈部的整片组织固定在胸廓，前倾时下端可离开对应椎骨约13.7cm。现在各附着位置跟随其实际所属的骨盆、腰段、胸廓或头颈帧，低细节版本由同一高细节表面转移权重。

相邻的背阔肌与源图谱命名为斜方肌下降部的左右四个对象，其内侧起始区原本使用不一致的躯干混合权重。修正这些后侧内侧肌腱／筋膜及相接肌纤维的附着场，并平滑过渡到原外侧权重，使组织一起弯曲。没有通过隐藏韧带来遮盖翘离。

韧带改变高细节24个、低细节4个顶点的绑定；相邻起始区改变1936个高细节、72个低细节顶点。源顶点位置、三角面、颜色、其他组织、51节点、臂部影响、运动求解与控件保持。没有增加顶点／面数或渲染通道，低细节非零骨权重总数从11322减少到11289；2.6.3配色与2.6.2播放时钟保持。此处不是新的设备帧率测试。

验证包含196组当前模型的三档跑速、前倾／后仰、四相位、多轴组合和站立检查，以及每细节69组邻近组织变形／接缝检查。高细节韧带附着点的额外漂移为数值零；低细节与变形后高细节表面的最大差约4.66mm。178组重合的高细节肌腱／纤维接缝权重一致。完整上身与蒙皮回归7项通过，真实骨骼仍按严格刚性检验，单列的韧带按可变形组织检验。实际云Chrome检查了后方／斜后方前倾15°、35°、站立以及组合转动；高细节是独立CPU诊断图，未验证GPU设备。

剩余限制：简化脊柱的少数刚性分段仍可在强弯曲下局部重叠；内部薄层肌肉三角面仍有相交，代表性局部平面交叠估计在35°约0.7mm、极端组合约3.0mm。这不是全身最大穿透深度或封闭体积穿透量。正常颜色检查中，背部原本脱离身体的薄片已消失，最大前倾保留连续的折弯；极端正向转身可从现有颈侧开口看到已附着的颈段组织。低细节仍保留原简化面片／缝隙。附着修正不等于完整碰撞排除或生理韧带／脊柱模型。

资产重建按顺序进行：
1. 用model-assets/build-hand-rig.py从保留的coherent-neutral-base.js生成coherent-hand-data.js
2. 运行model-assets/patch_interspinous.py --repo . --input <手部结果> --out <输出目录>
3. 运行model-assets/patch_back_origins.py --repo . --input <coherent-data.ligament-candidate.js> --out <输出目录>，将其coherent-data.back-bindings-final.js作为src/anatomy/coherent-data.js

需要numpy与vtk（验证版本9.3.1）。补丁检查源组织分区与修改范围，原中立参考保持原样；不要对已完成对应修正的文件重复执行该阶段。最新完整记录为QA-back-final.json；其他报告按其版本／阶段解读。

---

# 2.6.3：肌骨模型视觉调整（已保留）

肌肉采用低饱和暖陶红，骨骼为柔和象牙色，肌腱与软骨仍保留独立色组。背景与漫反射光更柔和，降低裸露标本的强烈红白反差。图层、肌肉点选、几何、绑定与动作完全保留，没有加入皮肤、人脸或服装。显示配色用于区分结构，不代表真实组织颜色。

四种显示色在加载时统一映射，Canvas使用sRGB色值，WebGL使用由同一色值换算的线性顶点色。兼容绘制减小面光照反差；WebGL移除发暗的漫反射纤维贴图，仅保留很弱的凹凸纹理与哑光材质。新增每帧几何／绘制调用为零，2.6.2的数据复用与播放时钟保持。

验证覆盖高／低细节几何、法线、权重和结构范围逐值相同，20组跑步／站立状态相同，18组Canvas绘制坐标与顺序相同，实际云Canvas正面／侧面／立体、肌肉点选和骨骼图层。WebGL配色通过代码与数值检查，未在GPU设备上实测。最新记录为QA-visual-polish.json，历史报告按版本解读。

---

# 2.6.2：1×播放性能修正（已保留）

主要优化是减少同一帧／同一求解迭代内重复的骨骼祖先矩阵计算。求解内部只更新与原质心／足底约束有关的21个节点；最终公开姿态完整更新51个节点，手部姿态保持。已更新的世界矩阵直接读取位置与四元数，恒定手指四元数和同相位示意参考重复利用。

Canvas兼容绘制保留全部9,788顶点、11,398三角形、原颜色／光照／深度顺序，复用三角面对象、颜色字符串与归属信息。不再附加32ms跳帧门槛，每次可绘制动画回调都呈现；1×参考周期、步频、关节轨迹和求解器收敛阈值不变。首帧若回调时间戳早于初始化完成时间，负时间差归零，避免瞬间反向推进。

验证：1371组完整数值结果／接触状态逐值相同，127296个51节点状态检查逐值相同，含失败保持、首次不可行、清空、复位、站立及公开调用。54组Canvas有效绘图命令相同。实际云Chrome Canvas配对观测：默认稳态动画回调间隔从约51～58ms降至32～34ms；混合编辑场景从约66ms降至44ms。模型更新均值约18～20ms降至5.4～5.7ms。冷启动／宿主调度仍可出现长帧，Canvas绘制本身仍占明显时间；这些不是用户设备、WebGL/GPU或通用60FPS保证。

以下2.6.1手部与2.6空间控制说明仍适用。最新性能验收见QA-performance-final.json；旧报告按各自版本保留。

---

# 2.6.1：三维运动约束与握拳修正

当前入口为 src/running-constraints.js：保留2.5的9坐标矢状面求解器作为意图／种子层（running-sagittal.js），最终由20坐标空间求解器决定渲染、目标误差和可行状态。以下较早2.5章节保留作设计沿革，不能把它的9坐标、YZ残差或默认世界轨迹逐值一致结论套用于2.6。

- +X为人体左、+Y向上、+Z前进。大腿世界前摆读数／目标来自实际髋→膝骨向量atan2(dz,−dy)，不是“髋角减骨盆角”的二维近似。
- 20坐标：根部XYZ平移、骨盆XYZ姿态，双侧髋屈伸／外展／股骨长轴旋转、膝单轴屈伸、踝三轴补偿。踝坐标是接触IK补偿自由度，不是经过个体解剖验证的距小腿／距下关节分解；没有膝扭矩或膝轴旋转。
- 腿部新增控件为相位成形的峰值增量。双侧正外展各向身体外；正内旋各绕股骨自身轴向内，左右符号镜像。股骨轴由膝的源绑定位置给定，轴旋转不移动膝中心。
- 骨盆侧倾正值抬高左侧，骨盆转向正值向左。骨盆相对世界的XYZ欧拉姿态参数被约束求解。胸廓控件增加相对骨盆的转动，实际值用相对四元数YXZ分解显示；世界转向另列。这三个是全身设置，不受侧别选择影响。
- 三维接触使用刚性四角足底代理。落地后固定平面位移和朝向，保留原脚跟到前掌的滚动；不是四角永远同时固定于地面。目标加入XYZ残差；摆动使用足中心插值与四元数球面插值，目标矩形不缩短。未来落地采用下一周期的原点，避免周期边界产生侧向跳跃。
- 腿幅度修改／清空在当前支撑中排队，下一摆动期接入；落地时保存新幅度与足坐标系。全身设置立即通过支撑腿／踝／根部补偿求解。失败回滚两层的接触状态；重置／切速／拖相位显式重建，避免缓存带入旧目标。
- 最终目标函数不依赖帧间dt；确定性种子与统一迭代预算。Jacobian采用平移1e−7m、角度2e−7rad差分，避免单边足底铰链残差造成镜像偏差。空间层膝参考尺度4°减少不必要的新增膝代偿；接触优先，目标2°阈值不变。 两层对髋前摆的额外目标偏好、空间层对外展／内旋的额外偏好，在绝对相位增量0～1°内平滑引入；零增量不会只因新增排队目标就改变物理目标函数。无效的当前零增量不计作未满足的活动目标，实际读数仍显示。
- 上身／骨盆节律是明确的作者示意。骨盆转向与参考胸廓反向；腰／胸分配相对旋转，头以世界四元数稳定。原肩／肘摆臂曲线与肩外展保留。30个源图谱枢轴手指节点完整屈曲成拳，拇指扣于外侧。前臂绕自身长轴校正掌向，使掌心朝内而非上翻；肩／肘屈伸及腕部中心摆动曲线保留。源绑定坐标的97～101°扭转不是临床旋前角。站立／摆姿仍恢复中立手形。

握拳专项：四根长指由浅屈曲改为完整指链屈曲，拇指位于外侧；左右高／低细节共588对非相邻手骨表面检查未发现接触。最小采样表面间距约0.66mm，但这不是完整软组织／实体碰撞验证。原最近线段弧长权重在弯曲PIP附近跳变，现改为源关节平分面平滑混合；只改146个高细节和2个低细节远端手腱权重。骨形、顶点、面、颜色、非手部权重不变。与2.6的540个默认／混合／单侧姿态比较，腕中心最大变化约0.003mm；保持既有三平面目标、接触与摆臂路径。

参考与变化：RBDS003三档矢状面源数组、周期／触地时程、映射步幅逐值保留；默认20坐标姿态会因3D适配发生小变化。最终检查的局部矢状关节差约≤0.52°、世界大腿前摆差≤0.22°、根部Y/Z差≤2.9mm。腾空脚空间位置与2.5最大相差约3.5／4.1／4.6cm（三档速度），接触脚保持原1mm验收门槛。默认腾空净空与光滑参考包络最大偏差约0.017mm；这是软目标的数值适配，验收0.05mm并独立检查不穿地。不能宣称所有默认世界轨迹完全相同。

RBDS本地数据包含髋AngX/Y，伴随论文说明Cardan Z–X–Y顺序，但双侧解剖正负号尚未可靠映射，因此没有冒充已使用这些实测空间曲线。没有捆绑骨盆／胸廓／手臂角度。新增空间节律是示意；不预测惯量、肌力、驱动力矩、摩擦冲量或动态稳定。

剩余限制：中等组合例（双侧前摆15／外展8／内旋−12、骨盆侧倾3／转向8、胸廓−10）在刚进入摆动、相位目标约0.025°且偏好正在渐入时，可短暂出现约8.31°原始角度误差并明确显示“目标受限”；空间范围边界组合测试约4.89°。这里没有把弱偏好的原始误差缩小后冒充达标。更极端负前摆仍可能出现快速连续代偿，内收／内旋组合可能出现交叉姿态。未求完整自碰撞、肌力或生理可行性。

验证：test-spatial-controls、test-spatial-transitions、test-spatial-coupling、test-actual-fps、test-integrated-upperbody，加上已更新的参考／双侧／状态回归与266项站立检查。30／60／120FPS检验使用对应时间步长比较求解结果，不是设备帧率实测。实际云Chrome仅Canvas2D兼容渲染；CSS视口390×844、844×390、800×600、1180×760检查不能当作真机、GPU或设备帧率验证。

---

# Reference motion, world-frame swing control and upper-body coordination (2.5)

## Reference and retargeting
The default motion uses participant RBDS003 from Fukuchi, Fukuchi & Duarte's public running-biomechanics dataset, version5 (CC BY4.0). That participant is classified as rearfoot-striking on both sides at2.5,3.5 and4.5m/s. It is one participant's averaged motion, not a population-normal prescription.

The application's reference is the mean of left/right sagittal AngZ curves for each speed. The two model legs use that common curve a half-cycle apart. Source knee angles include small negative values; the viewer adds6.1degrees as an explicit neutral-registration choice so the source minima fit the model's nonnegative knee-flexion range. Endpoints are averaged and shape-preserving periodic interpolation is applied. Original data, hashes, license, raw timing data and derivation script are bundled in motion-reference/.

The reference pelvis is the atlas neutral frame. Root translation is derived from the reference joint geometry and a heel-to-forefoot support pivot; foot trajectories and approximate COM targets are then calculated from that same pose. This replaces the old independently chosen swing arch, fixed foot-pitch trajectory and unrelated COM path that competed with the joint reference. During flight, a smooth12mm*sin²(phase) minimum proxy-clearance envelope provides retargeting clearance; it vanishes at the contact boundaries. The reference poses do not require ankle-angle saturation. This does not certify universally natural or clinically accurate motion.

## Bilateral editing semantics
Both-side is the initial editing scope. Knee/ankle sliders set the same local-joint reference offset on each leg's own phase-shifted trajectory. The running hip slider now sets a phase-shaped world-frame thigh swing increment, not a local hip angle; it never forces equal instantaneous angles. All three settings are persistent and may be combined. Changing trunk does not erase joint offsets.

Choosing left/right/both changes editing scope only. Existing asymmetric values remain unchanged. Mixed fields explicitly show each side's value; moving that bilateral slider synchronizes only that joint. Actual left/right angles remain visible separately. Reset clears the current mode's joint targets and restores its trunk/phase defaults; reference speed and playback multiplier are retained. Standing and running maintain separate target/trunk state.

## Speed and time units
Three measured-speed references are offered; no extrapolation outside these points is provided. Playback multiplier is a separate visualization control.

Source-speed reference | Source two-step period | Reference cadence (rounded) | Adapted full-stride distance | Adapted1x average speed
2.5m/s |0.7804888889s |154steps/min |1.5063056100m |1.929951m/s
3.5m/s |0.7379310345s |163steps/min |1.9859482802m |2.691233m/s
4.5m/s |0.7135s |168steps/min |2.4839461406m |3.481374m/s

Exact source timing is in timing-RBDS003-all-speeds.json; displayed values are rounded. One full cycle contains two steps, so cadence=120/cycleSeconds, not60/cycleSeconds. Adapted speed=strideMeters/cycleSeconds. The source treadmill reference is not labelled as the atlas's exact world speed: fixed atlas segment geometry and support-pivot retargeting change the stride distance. The UI states source reference speed, adapted full-stride length and mapped1x speed separately. Playback0.5x slows display without changing the selected reference curves or their nominal cadence metadata.

Raw timing was computed from300Hz force trials with fourth-order10Hz forward/backward Butterworth filtering,20N crossings and a minimum100N pulse-peak validation to exclude tiny filtering-ring pulses.100/300/500N validation choices retained identical contact counts. This is a reproducible analysis, not claimed as a published per-participant timing field. Source contact fractions from raw events and processed-curve finite/NaN endpoints are retained separately. The model uses processed contact boundaries0.34/0.32/0.305, consistent with the source's1%-phase resolution; physical support duration in the model is that fraction times the two-step period.

## Solver and limits
The same9-coordinate sagittal contact IK is used for edits: root Y/Z, pelvis pitch, bilateral hip/knee/ankle. Contact, floor clearance, anatomical software limits, reference COM/posture and continuous contact weights are prioritized over conflicting targets. Default retargeted references satisfy the geometric constraints directly. Target error is reported for every edited coordinate; rejected base-constraint solutions retain the previous complete pose and pause. Fixed segment lengths do not prove soft-tissue deformation accuracy.

This remains phase-driven constrained kinematics, not force-integrated dynamics. There are no dynamic inertias, muscle/actuator forces, friction impulses, strength constraints or neural control. Running does not impose static COM-in-foot balance or show ground-reaction estimates in flight. Standing retains its separate approximate70kg quasi-static mode.

## Verification
scripts/test-reference-bilateral.mjs verifies source-array reproduction,3-speed timing and units, reference ROM/no default ankle clamping, half-cycle alternation, combined/asymmetric offsets, transition continuity, flight clearance, limits/invalid input, actual low/high skinned foot geometry and DOM side/mode/reset behavior. QA-reference-bilateral.json records16 groups. The standing suite's266 checks also passes. Actual cloud-browser tests use labelled Canvas2D compatibility mode; this environment disables WebGL. Native Windows/macOS file-double-click and mobile are not directly tested, although the delivered HTML bundles all runtime data/dependencies.

The final DOM test additionally requires the development-only happy-dom package (tested version is recorded in the delivery instructions). Install it in the source project before running the full suite, or supply HAPPY_DOM_MODULE with an explicit module location. The shipped HTML itself does not use or require this QA dependency.

## World-frame swing control (2.5)
The running hip slider is labelled 大腿前摆幅度. It controls a signed peak world-frame thigh-angle increment (world vertical reference), weighted smoothly across the stride: highest near late swing, tapering to zero through mid/late stance. Negative values reduce forward swing. The actual anatomical hip angle relative to the pelvis and pelvis pitch remain visible separately. Standing modes retain anatomical hip-angle controls.

The earlier local hip-angle target allowed the pelvis and both hips to rotate together, raising the numeric hip value with much less visible thigh advancement. The current objective compares the actual world thigh angle and mildly penalizes pelvis pitch. Swing-foot goals and the intended next landing shift adapt with the edited posture; the proxy clearance envelope is retained. The current planted contact anchor cannot be moved by a slider. A changed or cleared hip amplitude is queued until the next swing, with the prior stance amplitude retained until takeoff; every touchdown snapshots a new amplitude, including zero. Foot anchor and amplitude state are rolled back if the solve is rejected.

Scrubbing or switching source speed explicitly rebuilds a deterministic pose with the current targets. Reset clears offsets, cached contact history and phase; switching between edit scopes does not reset or overwrite asymmetric targets. Therefore an intentional scrub/reset can move the pose, while a live stance edit keeps the current support anchor.

The edited-pose objective is phase/contact based, with a deterministic seed and shared convergence budget. Contact importance varies continuously in log space over a quarter of swing; stronger reference root-height/translation and knee posture terms suppress alternate crouch solutions. This replaces the old per-render-frame temporal penalty. Matched30/60/120FPS poses are compared at the same phase. Very large negative swing requests can still produce steep but continuous compensatory motion; constraints and displayed target errors do not imply physiological feasibility.

## Illustrative upper-body coordination (2.5)
The published RBDS marker protocol includes pelvis and legs only; its processed data has no thorax or arm trajectories. Upper-body motion is explicitly illustrative, not a measured or validated kinematic model. Source: https://pmc.ncbi.nlm.nih.gov/articles/PMC5426356/ Table 1.

The preceding shoulder/elbow changes largely cancelled in world space and kept both hands forward. The authored periodic shoulder/elbow curves now create a hip-to-chest hand arc. Continuous shape-preserving interpolation, shoulder axial rotation, small abduction, varying elbow flexion, pronation and wrist pitch give visible motion. The wrist moves opposite the same-side leg over the cycle. Equal hip edits no longer cancel out in the coordination calculation: each actual solved world-thigh angle independently affects its arm.

Chest turning follows the difference between the two arm excursions, with a small twice-per-cycle pitch and once-per-cycle roll. Lumbar and thorax share these rotations and the head partly counter-rotates. Chosen design limits, not measured normative ranges: chest yaw ±10°, roll within ±2.5°, pitch within ±2°, shoulder extension from −30° to58°, elbow flexion65–118°. Default shoulder-relative wrist fore/aft excursion is approximately39–41cm across the three speed references. Replay multiplier changes timing only.

No anatomical mesh, skin weights, default lower-limb pose, reference curves, contact trajectories, stride or timing are changed. Actual posed upper-body segments contribute to the approximate COM used when solving edited poses. Default lower-limb q and foot coordinates are checked exactly against accepted2.3; standing solver/assets/reference arrays remain byte-identical, while the model wrapper changes only reset/cache orchestration. Standing mode is also tested after repeated run switches.

Numerical/high-detail CPU skinning verification and actual cloud-browser Canvas2D checks are recorded separately. High-detail GPU rendering, device FPS, mobile and native Windows/macOS double-click are not verified. Soft-tissue deformation remains approximate, with no comprehensive self-collision or muscle-force model.
